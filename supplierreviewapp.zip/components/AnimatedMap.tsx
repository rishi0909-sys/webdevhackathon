"use client"

import { useEffect, useRef, useState } from "react"
import { useTheme } from "next-themes"
import { MapPin, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  distance?: number | null
  reviews: Array<{
    id: number
    user: string
    rating: number
    comment: string
    date: string
  }>
  icon: string
}

interface UserLocation {
  lat: number
  lng: number
  address: string
  city?: string
  state?: string
}

interface AnimatedMapProps {
  suppliers: Supplier[]
  selectedSupplier: number | null
  onSupplierSelect: (supplierId: number) => void
  mapCenter: { lat: number; lng: number }
  userLocation: UserLocation | null
}

export default function AnimatedMap({
  suppliers,
  selectedSupplier,
  onSupplierSelect,
  mapCenter,
  userLocation,
}: AnimatedMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<any[]>([])
  const userMarkerRef = useRef<any>(null)
  const [isMapLoaded, setIsMapLoaded] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)
  const { theme, systemTheme } = useTheme()
  const [mapTheme, setMapTheme] = useState("light")

  // Initialize map
  useEffect(() => {
    const initializeMap = async () => {
      try {
        // Load Leaflet CSS and JS
        if (!document.querySelector('link[href*="leaflet"]')) {
          const leafletCSS = document.createElement("link")
          leafletCSS.rel = "stylesheet"
          leafletCSS.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          document.head.appendChild(leafletCSS)
        }

        if (!window.L) {
          await new Promise((resolve, reject) => {
            const script = document.createElement("script")
            script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
            script.onload = resolve
            script.onerror = reject
            document.head.appendChild(script)
          })
        }

        if (mapRef.current && !mapInstanceRef.current) {
          // Initialize map
          mapInstanceRef.current = window.L.map(mapRef.current, {
            zoomControl: true,
            scrollWheelZoom: true,
            doubleClickZoom: true,
            touchZoom: true,
            dragging: true,
          }).setView([mapCenter.lat, mapCenter.lng], 13)

          // Add tile layer with theme support
          const isDark = document.documentElement.classList.contains("dark")
          const tileLayer = isDark
            ? window.L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                subdomains: "abcd",
                maxZoom: 19,
              })
            : window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                maxZoom: 19,
              })

          tileLayer.addTo(mapInstanceRef.current)

          setIsMapLoaded(true)
        }
      } catch (error) {
        console.error("Error initializing map:", error)
        setMapError("Failed to load map. Please refresh the page.")
      }
    }

    initializeMap()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  // Update map center
  useEffect(() => {
    if (mapInstanceRef.current && isMapLoaded) {
      mapInstanceRef.current.setView([mapCenter.lat, mapCenter.lng], 13)
    }
  }, [mapCenter, isMapLoaded])

  // Add user location marker
  useEffect(() => {
    if (mapInstanceRef.current && isMapLoaded && userLocation) {
      // Remove existing user marker
      if (userMarkerRef.current) {
        mapInstanceRef.current.removeLayer(userMarkerRef.current)
      }

      // Create user location marker
      const userIcon = window.L.divIcon({
        html: `
          <div class="relative">
            <div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
            <div class="absolute inset-0 w-4 h-4 bg-blue-500/30 rounded-full animate-ping"></div>
          </div>
        `,
        className: "user-location-marker",
        iconSize: [16, 16],
        iconAnchor: [8, 8],
      })

      userMarkerRef.current = window.L.marker([userLocation.lat, userLocation.lng], {
        icon: userIcon,
        zIndexOffset: 1000,
      }).addTo(mapInstanceRef.current)

      userMarkerRef.current.bindPopup(`
        <div class="p-2">
          <div class="flex items-center space-x-2 mb-2">
            <div class="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span class="font-semibold text-sm">Your Location</span>
          </div>
          <p class="text-xs text-gray-600">${userLocation.address}</p>
        </div>
      `)
    }
  }, [userLocation, isMapLoaded])

  // Add supplier markers
  useEffect(() => {
    if (mapInstanceRef.current && isMapLoaded) {
      // Clear existing markers
      markersRef.current.forEach((marker) => {
        mapInstanceRef.current.removeLayer(marker)
      })
      markersRef.current = []

      // Add supplier markers
      suppliers.forEach((supplier) => {
        const isSelected = selectedSupplier === supplier.id
        const supplierIcon = window.L.divIcon({
          html: `
            <div class="relative transform transition-all duration-300 ${isSelected ? "scale-125" : "hover:scale-110"}">
              <div class="w-10 h-10 bg-white rounded-full border-2 border-orange-500 shadow-lg flex items-center justify-center ${
                isSelected ? "ring-2 ring-blue-500 ring-opacity-50 border-blue-500" : ""
              }">
                <span class="text-lg">${supplier.icon}</span>
              </div>
              ${isSelected ? '<div class="absolute inset-0 w-10 h-10 bg-blue-500/20 rounded-full animate-ping"></div>' : ""}
            </div>
          `,
          className: "supplier-marker",
          iconSize: [40, 40],
          iconAnchor: [20, 20],
        })

        const marker = window.L.marker([supplier.location.lat, supplier.location.lng], {
          icon: supplierIcon,
        }).addTo(mapInstanceRef.current)

        // Create popup content
        const popupContent = `
          <div class="p-4 min-w-[280px] max-w-[320px]">
            <div class="flex items-start justify-between mb-3">
              <div class="flex-1">
                <div class="flex items-center space-x-2 mb-2">
                  <span class="text-2xl">${supplier.icon}</span>
                  <h3 class="font-bold text-lg text-gray-900">${supplier.name}</h3>
                </div>
                <span class="inline-block px-2 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">
                  ${supplier.category}
                </span>
              </div>
              <div class="text-right ml-3">
                <div class="flex items-center space-x-1">
                  <span class="text-yellow-500">⭐</span>
                  <span class="font-bold text-lg">${supplier.rating}</span>
                </div>
                <span class="text-xs text-gray-500">(${supplier.reviewCount} reviews)</span>
              </div>
            </div>
            
            <p class="text-sm text-gray-600 mb-3 line-clamp-2">${supplier.description}</p>
            
            <div class="flex items-center space-x-2 text-sm text-gray-500 mb-3">
              <span>📍</span>
              <span class="truncate">${supplier.location.address}</span>
              ${
                supplier.distance
                  ? `<span class="ml-auto bg-gray-100 px-2 py-1 rounded text-xs font-medium">${supplier.distance} mi</span>`
                  : ""
              }
            </div>
            
            <button 
              onclick="window.navigateToSupplier(${supplier.id}); event.stopPropagation();"
              class="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white py-2 px-4 rounded-lg font-semibold text-sm hover:from-orange-600 hover:to-red-600 transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <span>View Details</span>
              <span>→</span>
            </button>
          </div>
        `

        marker.bindPopup(popupContent, {
          maxWidth: 320,
          className: "custom-popup",
        })

        // Only select supplier on marker click, don't navigate
        marker.on("click", () => {
          onSupplierSelect(supplier.id)
        })

        markersRef.current.push(marker)
      })

      // Make navigation function globally available (only for View Details button)
      ;(window as any).navigateToSupplier = (supplierId: number) => {
        window.location.href = `/supplier/${supplierId}`
      }
    }
  }, [suppliers, selectedSupplier, isMapLoaded, onSupplierSelect])

  // Handle theme changes
  useEffect(() => {
    if (mapInstanceRef.current && isMapLoaded) {
      const isDark = document.documentElement.classList.contains("dark")

      // Remove existing tile layer
      mapInstanceRef.current.eachLayer((layer: any) => {
        if (layer._url) {
          mapInstanceRef.current.removeLayer(layer)
        }
      })

      // Add new tile layer based on theme
      const tileLayer = isDark
        ? window.L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            subdomains: "abcd",
            maxZoom: 19,
          })
        : window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19,
          })

      tileLayer.addTo(mapInstanceRef.current)
    }
  }, [isMapLoaded])

  if (mapError) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-destructive">
              <MapPin className="w-5 h-5" />
              <span>Map Error</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription className="mb-4">{mapError}</CardDescription>
            <Button onClick={() => window.location.reload()} variant="outline" className="w-full">
              Refresh Page
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="relative h-full w-full">
      <div ref={mapRef} className="h-full w-full rounded-lg overflow-hidden" />

      {!isMapLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary/20"></div>
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent absolute top-0"></div>
            </div>
            <div className="text-muted-foreground font-medium">Loading interactive map...</div>
          </div>
        </div>
      )}

      {/* Map Controls */}
      {isMapLoaded && (
        <div className="absolute top-4 right-4 z-10 space-y-2">
          <Button
            variant="secondary"
            size="sm"
            className="bg-white/90 backdrop-blur-sm shadow-lg hover:bg-white"
            onClick={() => {
              if (userLocation && mapInstanceRef.current) {
                mapInstanceRef.current.setView([userLocation.lat, userLocation.lng], 15)
              }
            }}
          >
            <Navigation className="w-4 h-4 mr-2" />
            My Location
          </Button>
        </div>
      )}

      {/* Supplier Count Badge */}
      {isMapLoaded && suppliers.length > 0 && (
        <div className="absolute bottom-4 left-4 z-10">
          <Badge variant="secondary" className="bg-white/90 backdrop-blur-sm shadow-lg text-foreground">
            {suppliers.length} suppliers found
          </Badge>
        </div>
      )}
    </div>
  )
}
