"use client"

import { useState } from "react"
import { X, Package, User, CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { createBooking, isSupabaseConfigured } from "@/lib/supabase"
import { useToast } from "@/hooks/use-toast"

interface Supplier {
  id: number
  name: string
  category: string
  icon: string
}

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
  supplier: Supplier
}

interface BookingFormData {
  customerName: string
  customerEmail: string
  customerPhone: string
  businessName: string
  quantity: string
  unit: string
  estimatedBudget: string
  deliveryDate: string
  deliveryAddress: string
  specialRequirements: string
}

const initialFormData: BookingFormData = {
  customerName: "",
  customerEmail: "",
  customerPhone: "",
  businessName: "",
  quantity: "",
  unit: "kg",
  estimatedBudget: "",
  deliveryDate: "",
  deliveryAddress: "",
  specialRequirements: "",
}

export default function BookingModal({ isOpen, onClose, supplier }: BookingModalProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<BookingFormData>(initialFormData)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [bookingId, setBookingId] = useState<string | null>(null)
  const { toast } = useToast()

  const handleInputChange = (field: keyof BookingFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(formData.customerName && formData.customerEmail && formData.customerPhone)
      case 2:
        return !!(formData.quantity && formData.unit && formData.deliveryDate && formData.deliveryAddress)
      default:
        return true
    }
  }

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => prev + 1)
    } else {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields before continuing.",
        variant: "destructive",
      })
    }
  }

  const handleBack = () => {
    setCurrentStep((prev) => prev - 1)
  }

  const handleSubmit = async () => {
    if (!validateStep(2)) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Check if we're in demo mode
      if (!isSupabaseConfigured()) {
        // Demo mode - simulate booking creation
        await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate API delay
        const mockBookingId = `demo-${Date.now()}`
        setBookingId(mockBookingId)
        setCurrentStep(3)

        toast({
          title: "Demo Booking Created! 🎉",
          description: "This is a demo booking. In production, the supplier would be notified.",
        })
      } else {
        // Production mode - create actual booking
        const bookingData = {
          supplier_id: supplier.id,
          supplier_name: supplier.name,
          customer_name: formData.customerName,
          customer_email: formData.customerEmail,
          customer_phone: formData.customerPhone,
          business_name: formData.businessName || undefined,
          product_category: supplier.category,
          quantity: Number.parseInt(formData.quantity),
          unit: formData.unit,
          estimated_budget: formData.estimatedBudget ? Number.parseFloat(formData.estimatedBudget) : undefined,
          delivery_date: formData.deliveryDate,
          delivery_address: formData.deliveryAddress,
          special_requirements: formData.specialRequirements || undefined,
        }

        const { data, error } = await createBooking(bookingData)

        if (error) {
          throw error
        }

        setBookingId(data.id)
        setCurrentStep(3)

        toast({
          title: "Booking Created Successfully! 🎉",
          description: "The supplier will contact you within 24 hours.",
        })
      }
    } catch (error) {
      console.error("Error creating booking:", error)
      toast({
        title: "Booking Failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClose = () => {
    setCurrentStep(1)
    setFormData(initialFormData)
    setBookingId(null)
    setIsSubmitting(false)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-0 shadow-2xl">
        <CardHeader className="relative bg-gradient-to-r from-orange-500/10 to-red-500/10 border-b border-white/20">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            className="absolute right-4 top-4 hover:bg-white/20 rounded-full p-2"
          >
            <X className="w-5 h-5" />
          </Button>

          <div className="flex items-center space-x-4 pr-12">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-3xl">{supplier.icon}</span>
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-slate-800 dark:text-slate-200">
                Book from {supplier.name}
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-400">
                {supplier.category} • Verified Supplier
              </CardDescription>
            </div>
          </div>

          {/* Demo Mode Alert */}
          {!isSupabaseConfigured() && (
            <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                  Demo Mode: Bookings won't be saved to database
                </span>
              </div>
            </div>
          )}

          {/* Progress Steps */}
          <div className="flex items-center justify-center space-x-4 mt-6">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all duration-300 ${
                    step <= currentStep
                      ? "bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg"
                      : "bg-slate-200 dark:bg-slate-700 text-slate-500"
                  }`}
                >
                  {step < currentStep ? <CheckCircle className="w-5 h-5" /> : step}
                </div>
                {step < 3 && (
                  <div
                    className={`w-12 h-1 mx-2 rounded-full transition-all duration-300 ${
                      step < currentStep
                        ? "bg-gradient-to-r from-orange-500 to-red-500"
                        : "bg-slate-200 dark:bg-slate-700"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </CardHeader>

        <CardContent className="p-8">
          {/* Step 1: Customer Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="flex items-center space-x-3 mb-6">
                <User className="w-6 h-6 text-orange-500" />
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Customer Information</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="customerName" className="text-sm font-medium">
                    Full Name *
                  </Label>
                  <Input
                    id="customerName"
                    value={formData.customerName}
                    onChange={(e) => handleInputChange("customerName", e.target.value)}
                    placeholder="Enter your full name"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customerEmail" className="text-sm font-medium">
                    Email Address *
                  </Label>
                  <Input
                    id="customerEmail"
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => handleInputChange("customerEmail", e.target.value)}
                    placeholder="your@email.com"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customerPhone" className="text-sm font-medium">
                    Phone Number *
                  </Label>
                  <Input
                    id="customerPhone"
                    value={formData.customerPhone}
                    onChange={(e) => handleInputChange("customerPhone", e.target.value)}
                    placeholder="+91 9876543210"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessName" className="text-sm font-medium">
                    Business Name
                  </Label>
                  <Input
                    id="businessName"
                    value={formData.businessName}
                    onChange={(e) => handleInputChange("businessName", e.target.value)}
                    placeholder="Your business name (optional)"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-6">
                <Button
                  onClick={handleNext}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Continue to Order Details
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Order Details */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="flex items-center space-x-3 mb-6">
                <Package className="w-6 h-6 text-orange-500" />
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Order Details</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="quantity" className="text-sm font-medium">
                    Quantity *
                  </Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => handleInputChange("quantity", e.target.value)}
                    placeholder="Enter quantity"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="unit" className="text-sm font-medium">
                    Unit *
                  </Label>
                  <select
                    id="unit"
                    value={formData.unit}
                    onChange={(e) => handleInputChange("unit", e.target.value)}
                    className="w-full px-3 py-2 bg-white/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="kg">Kilograms (kg)</option>
                    <option value="liters">Liters</option>
                    <option value="pieces">Pieces</option>
                    <option value="boxes">Boxes</option>
                    <option value="bags">Bags</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="estimatedBudget" className="text-sm font-medium">
                    Estimated Budget (₹)
                  </Label>
                  <Input
                    id="estimatedBudget"
                    type="number"
                    value={formData.estimatedBudget}
                    onChange={(e) => handleInputChange("estimatedBudget", e.target.value)}
                    placeholder="Optional budget estimate"
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deliveryDate" className="text-sm font-medium">
                    Delivery Date *
                  </Label>
                  <Input
                    id="deliveryDate"
                    type="date"
                    value={formData.deliveryDate}
                    onChange={(e) => handleInputChange("deliveryDate", e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                    className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryAddress" className="text-sm font-medium">
                  Delivery Address *
                </Label>
                <Textarea
                  id="deliveryAddress"
                  value={formData.deliveryAddress}
                  onChange={(e) => handleInputChange("deliveryAddress", e.target.value)}
                  placeholder="Enter complete delivery address"
                  rows={3}
                  className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="specialRequirements" className="text-sm font-medium">
                  Special Requirements
                </Label>
                <Textarea
                  id="specialRequirements"
                  value={formData.specialRequirements}
                  onChange={(e) => handleInputChange("specialRequirements", e.target.value)}
                  placeholder="Any special requirements or notes (optional)"
                  rows={3}
                  className="bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                />
              </div>

              <div className="flex justify-between pt-6">
                <Button
                  onClick={handleBack}
                  variant="outline"
                  className="px-8 py-3 rounded-xl font-semibold bg-transparent"
                >
                  Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Creating Booking...
                    </>
                  ) : (
                    "Create Booking"
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Confirmation */}
          {currentStep === 3 && (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-2xl">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-200 mb-2">
                  Booking Created Successfully! 🎉
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-lg">
                  Your booking request has been submitted to {supplier.name}
                </p>
              </div>

              {bookingId && (
                <div className="bg-slate-100 dark:bg-slate-800 rounded-xl p-4">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">Booking ID</p>
                  <Badge variant="secondary" className="text-lg px-4 py-2 font-mono">
                    {bookingId}
                  </Badge>
                </div>
              )}

              <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-xl p-6">
                <h4 className="font-semibold text-orange-800 dark:text-orange-200 mb-2">What happens next?</h4>
                <ul className="text-sm text-orange-700 dark:text-orange-300 space-y-1 text-left">
                  <li>• The supplier will review your booking request</li>
                  <li>• They will contact you within 24 hours to confirm details</li>
                  <li>• You'll receive pricing and delivery confirmation</li>
                  <li>• Payment terms will be discussed directly with the supplier</li>
                </ul>
              </div>

              <Button
                onClick={handleClose}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Close
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
