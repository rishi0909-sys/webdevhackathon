"use client"

import { useState } from "react"
import { X, Star, MapPin, Phone, Globe, Clock, Users, Award, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  distance?: number | null
  reviews: Array<{
    id: number
    user: string
    rating: number
    comment: string
    date: string
  }>
}

interface SupplierDetailModalProps {
  supplier: Supplier | null
  isOpen: boolean
  onClose: () => void
}

export default function SupplierDetailModal({ supplier, isOpen, onClose }: SupplierDetailModalProps) {
  const [activeTab, setActiveTab] = useState("overview")

  if (!isOpen || !supplier) return null

  const ratingDistribution = [
    { stars: 5, count: Math.floor(supplier.reviewCount * 0.6), percentage: 60 },
    { stars: 4, count: Math.floor(supplier.reviewCount * 0.25), percentage: 25 },
    { stars: 3, count: Math.floor(supplier.reviewCount * 0.1), percentage: 10 },
    { stars: 2, count: Math.floor(supplier.reviewCount * 0.03), percentage: 3 },
    { stars: 1, count: Math.floor(supplier.reviewCount * 0.02), percentage: 2 },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-background rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10 p-6 border-b border-border">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 hover:bg-background/20"
            onClick={onClose}
          >
            <X className="w-5 h-5" />
          </Button>

          <div className="flex items-start space-x-6">
            <div className="w-20 h-20 gradient-secondary rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-4xl">🏪</span>
            </div>

            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">{supplier.name}</h1>
              <div className="flex items-center space-x-4 mb-3">
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                  {supplier.category}
                </Badge>
                {supplier.distance && (
                  <Badge variant="secondary" className="bg-muted/50">
                    {supplier.distance} mi away
                  </Badge>
                )}
              </div>

              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                    <span className="text-2xl font-bold">{supplier.rating}</span>
                  </div>
                  <span className="text-muted-foreground">({supplier.reviewCount} reviews)</span>
                </div>

                <div className="flex items-center space-x-2 text-muted-foreground">
                  <MapPin className="w-5 h-5" />
                  <span>{supplier.location.address}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mx-6 mt-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="contact">Contact</TabsTrigger>
            </TabsList>

            <div className="p-6">
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Award className="w-5 h-5 text-primary" />
                      <span>About This Supplier</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed mb-4">{supplier.description}</p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-muted/30 rounded-lg">
                        <Users className="w-8 h-8 text-primary mx-auto mb-2" />
                        <div className="text-2xl font-bold">{supplier.reviewCount}</div>
                        <div className="text-sm text-muted-foreground">Happy Vendors</div>
                      </div>

                      <div className="text-center p-4 bg-muted/30 rounded-lg">
                        <Star className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                        <div className="text-2xl font-bold">{supplier.rating}</div>
                        <div className="text-sm text-muted-foreground">Average Rating</div>
                      </div>

                      <div className="text-center p-4 bg-muted/30 rounded-lg">
                        <TrendingUp className="w-8 h-8 text-green-500 mx-auto mb-2" />
                        <div className="text-2xl font-bold">98%</div>
                        <div className="text-sm text-muted-foreground">Satisfaction Rate</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Rating Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {ratingDistribution.map((item) => (
                      <div key={item.stars} className="flex items-center space-x-3">
                        <div className="flex items-center space-x-1 w-16">
                          <span className="text-sm font-medium">{item.stars}</span>
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        </div>
                        <Progress value={item.percentage} className="flex-1" />
                        <span className="text-sm text-muted-foreground w-12 text-right">{item.count}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Customer Reviews</h3>
                  <Badge variant="outline">{supplier.reviews.length} reviews</Badge>
                </div>

                <div className="space-y-4">
                  {supplier.reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-4">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="gradient-accent text-white font-bold">
                              {review.user.charAt(0)}
                            </AvatarFallback>
                          </Avatar>

                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                <span className="font-semibold">{review.user}</span>
                                <div className="flex items-center space-x-1">
                                  {[...Array(5)].map((_, i) => (
                                    <Star
                                      key={i}
                                      className={`w-4 h-4 ${
                                        i < review.rating
                                          ? "fill-yellow-400 text-yellow-400"
                                          : "text-muted-foreground/30"
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                              <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                                <Clock className="w-4 h-4" />
                                <span>{review.date}</span>
                              </div>
                            </div>
                            <p className="text-muted-foreground leading-relaxed">"{review.comment}"</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="contact" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                    <CardDescription>Get in touch with this supplier</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                      <MapPin className="w-5 h-5 text-primary" />
                      <div>
                        <div className="font-medium">Address</div>
                        <div className="text-sm text-muted-foreground">{supplier.location.address}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                      <Phone className="w-5 h-5 text-primary" />
                      <div>
                        <div className="font-medium">Phone</div>
                        <div className="text-sm text-muted-foreground">+1 (555) 123-4567</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                      <Globe className="w-5 h-5 text-primary" />
                      <div>
                        <div className="font-medium">Website</div>
                        <div className="text-sm text-muted-foreground">www.supplier-website.com</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                      <Clock className="w-5 h-5 text-primary" />
                      <div>
                        <div className="font-medium">Business Hours</div>
                        <div className="text-sm text-muted-foreground">Mon-Fri: 8:00 AM - 6:00 PM</div>
                      </div>
                    </div>

                    <div className="pt-4 space-y-3">
                      <Button className="w-full gradient-primary text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Now
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Globe className="w-4 h-4 mr-2" />
                        Visit Website
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
