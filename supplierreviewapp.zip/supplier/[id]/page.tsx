"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Star, MapPin, Phone, Globe, Clock, Users, Award, TrendingUp, Quote, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { defaultSuppliers } from "../../utils/mockSuppliers"

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  reviews: Array<{
    id: number
    user: string
    rating: number
    comment: string
    date: string
  }>
}

export default function SupplierDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [supplier, setSupplier] = useState<Supplier | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const supplierId = Number.parseInt(params.id as string)
    const foundSupplier = defaultSuppliers.find((s) => s.id === supplierId)

    if (foundSupplier) {
      setSupplier(foundSupplier)
    }
    setLoading(false)
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary/20"></div>
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent absolute top-0"></div>
          </div>
          <div className="text-muted-foreground font-medium">Loading supplier details...</div>
        </div>
      </div>
    )
  }

  if (!supplier) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Supplier Not Found</CardTitle>
            <CardDescription>The supplier you're looking for doesn't exist.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => router.push("/")} className="w-full">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Map
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const ratingDistribution = [
    { stars: 5, count: Math.floor(supplier.reviewCount * 0.6), percentage: 60 },
    { stars: 4, count: Math.floor(supplier.reviewCount * 0.25), percentage: 25 },
    { stars: 3, count: Math.floor(supplier.reviewCount * 0.1), percentage: 10 },
    { stars: 2, count: Math.floor(supplier.reviewCount * 0.03), percentage: 3 },
    { stars: 1, count: Math.floor(supplier.reviewCount * 0.02), percentage: 2 },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Button variant="ghost" onClick={() => router.push("/")} className="mb-6 hover:bg-background/20">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Map
          </Button>

          <div className="flex flex-col sm:flex-row items-start space-y-6 sm:space-y-0 sm:space-x-8">
            <div className="w-24 h-24 gradient-secondary rounded-3xl flex items-center justify-center shadow-xl">
              <span className="text-5xl">🏪</span>
            </div>

            <div className="flex-1">
              <h1 className="text-4xl font-bold text-foreground mb-4">{supplier.name}</h1>
              <div className="flex flex-wrap items-center gap-4 mb-4">
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-sm px-3 py-1">
                  {supplier.category}
                </Badge>
                <Badge variant="secondary" className="bg-muted/50 text-sm px-3 py-1">
                  Verified Supplier
                </Badge>
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-8">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <Star className="w-8 h-8 fill-yellow-400 text-yellow-400" />
                    <span className="text-3xl font-bold">{supplier.rating}</span>
                  </div>
                  <span className="text-muted-foreground text-lg">({supplier.reviewCount} reviews)</span>
                </div>

                <div className="flex items-center space-x-2 text-muted-foreground">
                  <MapPin className="w-5 h-5" />
                  <span className="text-lg">{supplier.location.address}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="overview" className="text-lg py-3">
              Overview
            </TabsTrigger>
            <TabsTrigger value="reviews" className="text-lg py-3">
              Reviews
            </TabsTrigger>
            <TabsTrigger value="contact" className="text-lg py-3">
              Contact
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-2xl">
                  <Award className="w-6 h-6 text-primary" />
                  <span>About This Supplier</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed text-lg mb-8">{supplier.description}</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-gradient-to-br from-muted/30 to-muted/10 rounded-2xl">
                    <Users className="w-12 h-12 text-primary mx-auto mb-4" />
                    <div className="text-3xl font-bold mb-2">{supplier.reviewCount}</div>
                    <div className="text-muted-foreground">Happy Vendors</div>
                  </div>

                  <div className="text-center p-6 bg-gradient-to-br from-muted/30 to-muted/10 rounded-2xl">
                    <Star className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                    <div className="text-3xl font-bold mb-2">{supplier.rating}</div>
                    <div className="text-muted-foreground">Average Rating</div>
                  </div>

                  <div className="text-center p-6 bg-gradient-to-br from-muted/30 to-muted/10 rounded-2xl">
                    <TrendingUp className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <div className="text-3xl font-bold mb-2">98%</div>
                    <div className="text-muted-foreground">Satisfaction Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Rating Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ratingDistribution.map((item) => (
                  <div key={item.stars} className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 w-20">
                      <span className="font-medium">{item.stars}</span>
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    </div>
                    <Progress value={item.percentage} className="flex-1 h-3" />
                    <span className="text-muted-foreground w-16 text-right">{item.count}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold">Customer Reviews</h3>
              <Badge variant="outline" className="text-lg px-4 py-2">
                {supplier.reviews.length} reviews
              </Badge>
            </div>

            <div className="space-y-6">
              {supplier.reviews.map((review) => (
                <Card key={review.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-16 h-16">
                        <AvatarFallback className="gradient-accent text-white font-bold text-xl">
                          {review.user.charAt(0)}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-4">
                            <span className="font-semibold text-lg">{review.user}</span>
                            <div className="flex items-center space-x-1">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-5 h-5 ${
                                    i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            <span>{review.date}</span>
                          </div>
                        </div>

                        <div className="relative">
                          <Quote className="w-6 h-6 text-primary/30 absolute -top-2 -left-2" />
                          <p className="text-muted-foreground leading-relaxed text-lg pl-4">{review.comment}</p>
                        </div>

                        <div className="flex items-center space-x-4 mt-4">
                          <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary">
                            <ThumbsUp className="w-4 h-4 mr-2" />
                            Helpful
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="contact" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Contact Information</CardTitle>
                <CardDescription className="text-lg">Get in touch with this supplier</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4 p-4 bg-muted/30 rounded-xl">
                  <MapPin className="w-6 h-6 text-primary" />
                  <div>
                    <div className="font-medium text-lg">Address</div>
                    <div className="text-muted-foreground">{supplier.location.address}</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-muted/30 rounded-xl">
                  <Phone className="w-6 h-6 text-primary" />
                  <div>
                    <div className="font-medium text-lg">Phone</div>
                    <div className="text-muted-foreground">+1 (555) 123-4567</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-muted/30 rounded-xl">
                  <Globe className="w-6 h-6 text-primary" />
                  <div>
                    <div className="font-medium text-lg">Website</div>
                    <div className="text-muted-foreground">www.supplier-website.com</div>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-muted/30 rounded-xl">
                  <Clock className="w-6 h-6 text-primary" />
                  <div>
                    <div className="font-medium text-lg">Business Hours</div>
                    <div className="text-muted-foreground">Mon-Fri: 8:00 AM - 6:00 PM</div>
                  </div>
                </div>

                <div className="pt-6 space-y-4">
                  <Button className="w-full gradient-primary text-white text-lg py-6">
                    <Phone className="w-5 h-5 mr-3" />
                    Call Now
                  </Button>
                  <Button variant="outline" className="w-full text-lg py-6 bg-transparent">
                    <Globe className="w-5 h-5 mr-3" />
                    Visit Website
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
