import { createClient } from "@supabase/supabase-js"

// Database types
export interface Booking {
  id: string
  supplier_id: number
  supplier_name: string
  customer_name: string
  customer_email: string
  customer_phone: string
  business_name?: string
  product_category: string
  quantity: number
  unit: string
  estimated_budget?: number
  delivery_date: string
  delivery_address: string
  special_requirements?: string
  status: "pending" | "confirmed" | "cancelled" | "completed"
  created_at: string
  updated_at: string
}

export interface BookingInsert {
  supplier_id: number
  supplier_name: string
  customer_name: string
  customer_email: string
  customer_phone: string
  business_name?: string
  product_category: string
  quantity: number
  unit: string
  estimated_budget?: number
  delivery_date: string
  delivery_address: string
  special_requirements?: string
}

// Check if Supabase environment variables are available
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// Create Supabase client or mock client
let supabase: any

if (supabaseUrl && supabaseAnonKey) {
  supabase = createClient(supabaseUrl, supabaseAnonKey)
} else {
  // Mock client for development/demo mode
  console.warn("Supabase environment variables not found. Running in demo mode.")

  supabase = {
    from: (table: string) => ({
      insert: async (data: any) => {
        console.log("Demo mode: Would insert booking:", data)
        // Simulate successful insertion with a mock ID
        return {
          data: { ...data, id: `demo-${Date.now()}` },
          error: null,
        }
      },
      select: async () => {
        console.log("Demo mode: Would select from", table)
        return {
          data: [],
          error: null,
        }
      },
    }),
  }
}

export { supabase }

// Helper functions
export const createBooking = async (bookingData: BookingInsert) => {
  try {
    const { data, error } = await supabase.from("bookings").insert([bookingData]).select().single()

    if (error) {
      console.error("Error creating booking:", error)
      throw error
    }

    return { data, error: null }
  } catch (error) {
    console.error("Error in createBooking:", error)
    return { data: null, error }
  }
}

export const getBookingsBySupplier = async (supplierId: number) => {
  try {
    const { data, error } = await supabase
      .from("bookings")
      .select("*")
      .eq("supplier_id", supplierId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching bookings:", error)
      throw error
    }

    return { data, error: null }
  } catch (error) {
    console.error("Error in getBookingsBySupplier:", error)
    return { data: null, error }
  }
}

export const updateBookingStatus = async (bookingId: string, status: Booking["status"]) => {
  try {
    const { data, error } = await supabase.from("bookings").update({ status }).eq("id", bookingId).select().single()

    if (error) {
      console.error("Error updating booking status:", error)
      throw error
    }

    return { data, error: null }
  } catch (error) {
    console.error("Error in updateBookingStatus:", error)
    return { data: null, error }
  }
}

// Check if Supabase is properly configured
export const isSupabaseConfigured = () => {
  return !!(supabaseUrl && supabaseAnonKey)
}
