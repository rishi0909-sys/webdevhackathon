"use client"

import { useState, useEffect } from "react"
import {
  Search,
  MapPin,
  Star,
  Filter,
  Navigation,
  ShoppingCart,
  Moon,
  Sun,
  Quote,
  ThumbsUp,
  Clock,
  ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useTheme } from "next-themes"
import dynamic from "next/dynamic"
import { generateSuppliersNearLocation, mockSuppliers } from "../utils/mockSuppliers"
import { supplierStore } from "../utils/supplierStore"

// Dynamically import the map component to avoid SSR issues
const AnimatedMap = dynamic(() => import("../components/AnimatedMap"), {
  ssr: false,
  loading: () => (
    <div className="h-full bg-gradient-to-br from-background to-muted flex items-center justify-center">
      <div className="flex flex-col items-center space-y-4">
        <div className="relative">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary/20"></div>
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent absolute top-0"></div>
        </div>
        <div className="text-muted-foreground font-medium">Loading map...</div>
      </div>
    </div>
  ),
})

interface UserLocation {
  lat: number
  lng: number
  address: string
  city?: string
  state?: string
}

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  distance?: number | null
  reviews: Array<{
    id: number
    user: string
    rating: number
    comment: string
    date: string
  }>
  icon: string
}

export default function SupplierReviewApp() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null)
  const [selectedLocation, setSelectedLocation] = useState("Detecting location...")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSupplier, setSelectedSupplier] = useState<number | null>(null)
  const [mapCenter, setMapCenter] = useState({ lat: 26.8467, lng: 80.9462 }) // Default to Lucknow
  const [locationLoading, setLocationLoading] = useState(true)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [suppliersData, setSuppliersData] = useState(mockSuppliers)

  useEffect(() => {
    setMounted(true)
    // Initialize with mock suppliers immediately
    supplierStore.setSuppliers(mockSuppliers)
    console.log("Initialized with mock suppliers:", mockSuppliers.length)

    // Also ensure store has the initialize method available
    supplierStore.initializeWithMockSuppliers()
  }, [])

  // Get user's current location and generate suppliers
  const getUserLocation = async () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by this browser")
      setSelectedLocation("Lucknow, Uttar Pradesh")
      setLocationLoading(false)
      return
    }

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000,
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords

        const basicLocation: UserLocation = {
          lat: latitude,
          lng: longitude,
          address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
          city: "Current City",
          state: "Current State",
        }

        setUserLocation(basicLocation)
        setMapCenter({ lat: latitude, lng: longitude })

        try {
          let addressData = null
          let detectedCity = "Current City"
          let detectedState = "Current State"

          try {
            const response1 = await fetch(
              `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`,
              { timeout: 5000 },
            )
            if (response1.ok) {
              addressData = await response1.json()
            }
          } catch (e) {
            console.log("BigDataCloud failed, trying alternative...")
          }

          if (!addressData) {
            try {
              const response2 = await fetch(
                `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=10&addressdetails=1`,
                {
                  timeout: 5000,
                  headers: {
                    "User-Agent": "VendorHub-App",
                  },
                },
              )
              if (response2.ok) {
                const osmData = await response2.json()
                addressData = {
                  city: osmData.address?.city || osmData.address?.town || osmData.address?.village,
                  principalSubdivision: osmData.address?.state || osmData.address?.province,
                  locality: osmData.address?.suburb || osmData.address?.neighbourhood,
                }
              }
            } catch (e) {
              console.log("OSM also failed...")
            }
          }

          if (addressData) {
            detectedCity =
              addressData.city ||
              addressData.locality ||
              addressData.localityInfo?.administrative?.[2]?.name ||
              "Current City"
            detectedState = addressData.principalSubdivision || addressData.principalSubdivisionCode || "Current State"
            const address =
              detectedCity && detectedState
                ? `${detectedCity}, ${detectedState}`
                : `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`

            const detailedLocation: UserLocation = {
              lat: latitude,
              lng: longitude,
              address: address,
              city: detectedCity,
              state: detectedState,
            }

            setUserLocation(detailedLocation)
            setSelectedLocation(address)
          } else {
            setSelectedLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`)
          }

          // Generate suppliers with local addresses and store them globally
          console.log(`Generating suppliers for: ${detectedCity}, ${detectedState}`)
          const nearbySuppliers = generateSuppliersNearLocation(latitude, longitude, detectedCity, detectedState, 18)
          setSuppliersData(nearbySuppliers)
          supplierStore.setSuppliers(nearbySuppliers)

          setLocationLoading(false)
        } catch (error) {
          console.error("Error getting address:", error)
          setSelectedLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`)
          // Even on error, use the coordinates to generate local suppliers
          const nearbySuppliers = generateSuppliersNearLocation(latitude, longitude, "Local Area", "Current Region", 18)
          setSuppliersData(nearbySuppliers)
          supplierStore.setSuppliers(nearbySuppliers)
          setLocationLoading(false)
        }
      },
      (error) => {
        console.error("Geolocation error:", error)
        let errorMessage = "Unable to get location"

        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied. Using default location."
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable. Using default location."
            break
          case error.TIMEOUT:
            errorMessage = "Location request timed out. Using default location."
            break
        }

        setLocationError(errorMessage)
        setSelectedLocation("Lucknow, Uttar Pradesh")
        // Keep using mock suppliers on geolocation failure
        setLocationLoading(false)
      },
      options,
    )
  }

  useEffect(() => {
    getUserLocation()
  }, [])

  // Calculate distance between two points
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371
    const dLat = ((lat2 - lat1) * Math.PI) / 180
    const dLon = ((lon2 - lon1) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const d = R * c
    return Math.round(d * 0.621371)
  }

  // Filter and sort suppliers by distance
  const filteredSuppliers = suppliersData
    .filter((supplier) => {
      const matchesSearch =
        supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        supplier.description.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesCategory =
        selectedCategory === "all" || supplier.category.toLowerCase() === selectedCategory.toLowerCase()
      return matchesSearch && matchesCategory
    })
    .map((supplier) => ({
      ...supplier,
      distance: userLocation
        ? calculateDistance(userLocation.lat, userLocation.lng, supplier.location.lat, supplier.location.lng)
        : null,
    }))
    .sort((a, b) => {
      if (a.distance === null || b.distance === null) return 0
      return a.distance - b.distance
    })

  const categories = ["all", ...Array.from(new Set(suppliersData.map((s) => s.category)))]

  const handleSupplierSelect = (supplierId: number) => {
    setSelectedSupplier(supplierId)
    const supplier = suppliersData.find((s) => s.id === supplierId)
    if (supplier) {
      setMapCenter(supplier.location)
    }
  }

  const handleSupplierCardClick = (supplierId: number) => {
    // Navigate to supplier details page when clicking on cards
    window.location.href = `/supplier/${supplierId}`
  }

  const requestLocationAgain = () => {
    setLocationLoading(true)
    setLocationError(null)
    setSelectedLocation("Detecting location...")
    getUserLocation()
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Full Viewport Map Section */}
      <section className="relative h-screen w-full">
        {/* Enhanced Floating Header */}
        <header className="absolute top-0 left-0 right-0 z-20 glass-effect shadow-lg border-b border-border/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center shadow-lg">
                  <ShoppingCart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                    VendorHub
                  </h1>
                  <Badge variant="outline" className="text-xs mt-1">
                    Street Food Wholesale
                  </Badge>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4 w-full sm:w-auto">
                <div className="relative w-full sm:w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search wholesalers..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 glass-effect border-border/50 focus-ring"
                  />
                </div>

                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full sm:w-40 glass-effect border-border/50 focus-ring">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category === "all" ? "All Categories" : category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                  className="glass-effect border-border/50 focus-ring"
                >
                  <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                  <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  <span className="sr-only">Toggle theme</span>
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Map Container - Full Height */}
        <div className="h-full w-full pt-24 sm:pt-20">
          <AnimatedMap
            suppliers={filteredSuppliers}
            selectedSupplier={selectedSupplier}
            onSupplierSelect={handleSupplierSelect}
            mapCenter={mapCenter}
            userLocation={userLocation}
          />
        </div>
      </section>

      {/* Enhanced Suppliers List Section */}
      <section
        id="suppliers-section"
        className="relative bg-gradient-to-br from-background via-muted/10 to-background py-12 sm:py-16 lg:py-24 overflow-hidden"
      >
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `radial-gradient(circle at 25% 25%, hsl(var(--primary)) 0%, transparent 50%), 
                             radial-gradient(circle at 75% 75%, hsl(var(--accent)) 0%, transparent 50%)`,
            }}
          ></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-12 sm:mb-16 lg:mb-20">
            <div className="inline-flex items-center space-x-2 sm:space-x-3 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10 text-primary px-4 sm:px-6 py-2 sm:py-3 rounded-full text-xs sm:text-sm font-semibold mb-4 sm:mb-6 shadow-lg backdrop-blur-sm border border-primary/20">
              <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="truncate">Near {selectedLocation}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 sm:mb-6 lg:mb-8 tracking-tight px-4">
              <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent">
                Premium Wholesale
              </span>
              <br />
              <span className="text-2xl sm:text-3xl lg:text-4xl">Suppliers & Reviews</span>
            </h2>

            <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed px-4">
              Discover verified wholesale suppliers with authentic reviews from fellow street food vendors. Quality
              ingredients, competitive prices, and reliable partnerships for your business success.
            </p>

            {locationError && (
              <div className="mt-6 sm:mt-8 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border border-yellow-200 dark:border-yellow-800 rounded-2xl max-w-md mx-auto shadow-lg">
                <p className="text-sm text-yellow-800 dark:text-yellow-200 font-medium">{locationError}</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={requestLocationAgain}
                  className="mt-2 bg-transparent text-yellow-800 dark:text-yellow-200 border-yellow-300 dark:border-yellow-700 hover:bg-yellow-100 dark:hover:bg-yellow-900/30"
                >
                  Try Again
                </Button>
              </div>
            )}
          </div>

          {/* Suppliers Grid - Fully Responsive */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8">
            {filteredSuppliers.map((supplier, index) => (
              <div
                key={supplier.id}
                className={`supplier-card group cursor-pointer transition-all duration-700 hover:shadow-2xl hover:shadow-primary/20 transform hover:-translate-y-2 ${
                  selectedSupplier === supplier.id
                    ? "ring-2 ring-primary shadow-2xl shadow-primary/30 scale-[1.02]"
                    : "hover:ring-1 hover:ring-primary/50"
                } overflow-hidden relative`}
                onClick={() => handleSupplierCardClick(supplier.id)}
                style={{
                  animationDelay: `${index * 150}ms`,
                }}
              >
                {/* Main Card Container */}
                <div className="bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-xl rounded-2xl border border-border/50 h-full flex flex-col">
                  {/* Card Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"></div>

                  {/* Header Section */}
                  <div className="p-4 sm:p-6 pb-3 sm:pb-4 relative z-10">
                    <div className="flex items-start justify-between gap-4">
                      {/* Left Side - Supplier Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start space-x-3 sm:space-x-4 mb-3">
                          <div className="relative flex-shrink-0">
                            <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-white to-gray-50 border-2 border-primary/20 rounded-xl sm:rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-500 group-hover:scale-110">
                              <span className="text-xl sm:text-2xl">{supplier.icon}</span>
                            </div>
                            <div className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-green-500 rounded-full flex items-center justify-center shadow-md">
                              <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-white rounded-full"></div>
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-lg sm:text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-300 truncate">
                              {supplier.name}
                            </h3>
                            <Badge
                              variant="outline"
                              className="text-xs font-semibold bg-primary/10 text-primary border-primary/20 mt-1"
                            >
                              {supplier.category}
                            </Badge>
                          </div>
                        </div>

                        {/* Location */}
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                          <MapPin className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="truncate font-medium">{supplier.location.address}</span>
                        </div>

                        {/* Distance Badge */}
                        {supplier.distance && (
                          <Badge
                            variant="secondary"
                            className="text-xs bg-gradient-to-r from-primary/20 to-accent/20 text-primary font-bold"
                          >
                            {supplier.distance} mi away
                          </Badge>
                        )}
                      </div>

                      {/* Right Side - Rating */}
                      <div className="text-right flex-shrink-0">
                        <div className="flex items-center space-x-1 justify-end mb-1">
                          <Star className="w-5 h-5 sm:w-6 sm:h-6 fill-yellow-400 text-yellow-400 drop-shadow-sm" />
                          <span className="font-bold text-xl sm:text-2xl text-foreground">{supplier.rating}</span>
                        </div>
                        <span className="text-xs sm:text-sm text-muted-foreground font-medium">
                          ({supplier.reviewCount} reviews)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Content Section */}
                  <div className="px-4 sm:px-6 pb-4 sm:pb-6 flex-1 flex flex-col relative z-10">
                    {/* Description */}
                    <p className="text-sm sm:text-base text-muted-foreground leading-relaxed font-medium mb-4 sm:mb-6 line-clamp-3">
                      {supplier.description}
                    </p>

                    {/* Reviews Section */}
                    <div className="flex-1 flex flex-col">
                      <div className="flex items-center space-x-2 mb-3 sm:mb-4">
                        <Quote className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                        <h4 className="font-bold text-foreground text-sm sm:text-base">Recent Reviews</h4>
                      </div>

                      {/* Reviews List */}
                      <div className="space-y-3 sm:space-y-4 flex-1">
                        {supplier.reviews.slice(0, 2).map((review, reviewIndex) => (
                          <div
                            key={review.id}
                            className="p-3 sm:p-4 bg-gradient-to-r from-muted/40 via-muted/20 to-muted/40 rounded-xl border border-border/50 backdrop-blur-sm group-hover:from-primary/5 group-hover:via-transparent group-hover:to-accent/5 transition-all duration-500"
                          >
                            <div className="flex space-x-3">
                              <Avatar className="w-8 h-8 sm:w-10 sm:h-10 shadow-md ring-2 ring-background flex-shrink-0">
                                <AvatarFallback className="text-xs sm:text-sm font-bold gradient-accent text-white">
                                  {review.user.charAt(0)}
                                </AvatarFallback>
                              </Avatar>

                              <div className="flex-1 min-w-0">
                                {/* Review Header */}
                                <div className="flex items-start justify-between gap-2 mb-2">
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center space-x-2 mb-1">
                                      <span className="text-xs sm:text-sm font-bold text-foreground truncate">
                                        {review.user}
                                      </span>
                                      <div className="flex items-center space-x-0.5">
                                        {[...Array(5)].map((_, i) => (
                                          <Star
                                            key={i}
                                            className={`w-3 h-3 ${
                                              i < review.rating
                                                ? "fill-yellow-400 text-yellow-400"
                                                : "text-muted-foreground/30"
                                            }`}
                                          />
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center space-x-1 text-xs text-muted-foreground flex-shrink-0">
                                    <Clock className="w-3 h-3" />
                                    <span>{review.date}</span>
                                  </div>
                                </div>

                                {/* Review Content */}
                                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed font-medium line-clamp-2 mb-2">
                                  "{review.comment}"
                                </p>

                                {/* Review Actions */}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 px-2 text-xs hover:bg-primary/10 hover:text-primary"
                                >
                                  <ThumbsUp className="w-3 h-3 mr-1" />
                                  Helpful
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* View More Reviews Button */}
                      {supplier.reviews.length > 2 && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full mt-3 sm:mt-4 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20 hover:from-primary/10 hover:to-accent/10 hover:border-primary/30 text-primary font-semibold text-xs sm:text-sm"
                        >
                          View All {supplier.reviews.length} Reviews
                          <ExternalLink className="w-3 h-3 ml-2" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {filteredSuppliers.length === 0 && (
            <div className="text-center py-12 sm:py-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6">
                <Search className="w-8 h-8 sm:w-10 sm:h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-2 sm:mb-4">No suppliers found</h3>
              <p className="text-muted-foreground mb-4 sm:mb-6 px-4">
                {searchQuery || selectedCategory !== "all"
                  ? "Try adjusting your search or filters"
                  : "No wholesale suppliers found in your area"}
              </p>
              <Button variant="outline" className="bg-transparent">
                Refresh Search
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Enhanced Features Section */}
      <section className="bg-gradient-to-br from-card via-card/50 to-background py-16 sm:py-20 lg:py-24 border-t border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16 lg:mb-20">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4 sm:mb-6 lg:mb-8 tracking-tight">
              Why Choose VendorHub?
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed px-4">
              The ultimate platform connecting street food vendors with trusted wholesale suppliers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12">
            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 gradient-primary rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-4 sm:mb-6 lg:mb-8 shadow-2xl group-hover:shadow-3xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                <Navigation className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-3 sm:mb-4 lg:mb-6 text-foreground group-hover:text-primary transition-colors duration-300">
                Location-Based
              </h3>
              <p className="text-muted-foreground leading-relaxed text-sm sm:text-base lg:text-lg px-2">
                Find wholesale suppliers near your food stall or cart with GPS location detection and distance
                calculation.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 gradient-accent rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-4 sm:mb-6 lg:mb-8 shadow-2xl group-hover:shadow-3xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                <Star className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-3 sm:mb-4 lg:mb-6 text-foreground group-hover:text-primary transition-colors duration-300">
                Vendor Reviews
              </h3>
              <p className="text-muted-foreground leading-relaxed text-sm sm:text-base lg:text-lg px-2">
                Read authentic reviews from fellow street food vendors to make informed supplier decisions.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 gradient-secondary rounded-2xl sm:rounded-3xl flex items-center justify-center mx-auto mb-4 sm:mb-6 lg:mb-8 shadow-2xl group-hover:shadow-3xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                <ShoppingCart className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-3 sm:mb-4 lg:mb-6 text-foreground group-hover:text-primary transition-colors duration-300">
                Wholesale Focus
              </h3>
              <p className="text-muted-foreground leading-relaxed text-sm sm:text-base lg:text-lg px-2">
                Specialized platform for street food wholesale - bulk pricing, vendor-friendly terms, and food-safe
                products.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
