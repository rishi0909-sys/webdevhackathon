"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import {
  ArrowLeft,
  Star,
  MapPin,
  Phone,
  Globe,
  Clock,
  Users,
  Award,
  TrendingUp,
  Quote,
  ThumbsUp,
  Shield,
  Verified,
  Calendar,
  MessageCircle,
  ShoppingCart,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import BookingModal from "@/components/BookingModal"

// Comprehensive supplier data generator
const supplierNames = [
  "Fresh Valley Wholesale",
  "Metro Food Distributors",
  "Golden Harvest Supply",
  "Urban Kitchen Partners",
  "Prime Ingredients Co.",
  "Street Food Central",
  "Quality Provisions Inc.",
  "Wholesale Food Hub",
  "City Market Suppliers",
  "Fresh Direct Wholesale",
  "Gourmet Supply Chain",
  "Local Harvest Distributors",
  "Food Service Partners",
  "Bulk Buy Specialists",
  "Restaurant Supply Co.",
  "Wholesale Kitchen Solutions",
  "Farm Fresh Distributors",
  "Commercial Food Supply",
  "Vendor Support Network",
  "Street Eats Wholesale",
  "Premium Food Sources",
  "Market Fresh Supply",
  "Culinary Wholesale Hub",
  "Food Trade Partners",
  "Bulk Ingredient Co.",
  "Wholesale Pantry Plus",
  "Fresh Market Direct",
  "Food Distribution Network",
  "Vendor's Choice Supply",
  "Wholesale Food Express",
  "Quality Food Partners",
  "Street Vendor Supply",
  "Fresh Ingredient Hub",
  "Wholesale Market Pro",
  "Food Service Direct",
  "Bulk Food Solutions",
  "Premium Wholesale Co.",
  "Market Supply Chain",
  "Food Vendor Partners",
  "Wholesale Kitchen Hub",
  "Fresh Supply Network",
  "Quality Food Direct",
  "Bulk Ingredient Hub",
  "Wholesale Food Pro",
  "Street Food Supply Co.",
  "Fresh Market Hub",
  "Food Distribution Pro",
  "Wholesale Ingredient Co.",
  "Quality Supply Chain",
  "Fresh Food Partners",
  "Bulk Market Direct",
  "Wholesale Food Network",
  "Premium Supply Hub",
  "Food Service Pro",
  "Wholesale Market Co.",
  "Fresh Ingredient Pro",
  "Quality Food Hub",
  "Bulk Supply Network",
  "Wholesale Food Direct",
  "Premium Market Co.",
  "Fresh Supply Pro",
  "Food Distribution Hub",
  "Wholesale Ingredient Network",
  "Quality Market Direct",
  "Bulk Food Partners",
  "Fresh Wholesale Co.",
  "Premium Food Hub",
  "Market Supply Pro",
  "Wholesale Food Solutions",
  "Fresh Market Network",
  "Quality Supply Hub",
  "Bulk Ingredient Network",
  "Premium Wholesale Hub",
  "Food Market Direct",
  "Fresh Supply Solutions",
  "Wholesale Food Partners",
  "Quality Market Hub",
  "Bulk Supply Pro",
  "Premium Food Network",
  "Fresh Wholesale Hub",
  "Market Distribution Co.",
  "Food Supply Solutions",
  "Wholesale Market Network",
  "Fresh Ingredient Solutions",
  "Quality Food Network",
  "Bulk Market Hub",
  "Premium Supply Co.",
  "Fresh Food Solutions",
  "Wholesale Ingredient Hub",
  "Market Supply Solutions",
  "Food Distribution Solutions",
  "Fresh Market Pro",
  "Quality Wholesale Hub",
  "Bulk Food Network",
  "Premium Market Hub",
  "Fresh Supply Co.",
  "Wholesale Food Hub Pro",
  "Market Ingredient Solutions",
  "Food Supply Network",
  "Fresh Distribution Hub",
  "Quality Market Solutions",
  "Bulk Wholesale Co.",
  "Premium Food Solutions",
  "Fresh Market Solutions",
  "Wholesale Supply Network",
  "Market Food Hub",
  "Quality Distribution Co.",
  "Bulk Ingredient Solutions",
]

const categories = [
  "Fresh Produce",
  "Meat & Poultry",
  "Dairy Products",
  "Beverages",
  "Packaged Foods",
  "Spices & Seasonings",
  "Bakery Items",
  "Frozen Foods",
  "Seafood",
  "Grains & Cereals",
  "Oils & Condiments",
  "Snacks & Confectionery",
  "Organic Products",
  "International Foods",
]

const categoryIcons: Record<string, string> = {
  "Fresh Produce": "🥬",
  "Meat & Poultry": "🥩",
  "Dairy Products": "🥛",
  Beverages: "🥤",
  "Packaged Foods": "📦",
  "Spices & Seasonings": "🌶️",
  "Bakery Items": "🥖",
  "Frozen Foods": "🧊",
  Seafood: "🐟",
  "Grains & Cereals": "🌾",
  "Oils & Condiments": "🫒",
  "Snacks & Confectionery": "🍿",
  "Organic Products": "🌱",
  "International Foods": "🌍",
}

const categoryColors: Record<string, string> = {
  "Fresh Produce": "from-green-600 to-emerald-600 text-white",
  "Meat & Poultry": "from-red-600 to-rose-600 text-white",
  "Dairy Products": "from-blue-600 to-cyan-600 text-white",
  Beverages: "from-purple-600 to-violet-600 text-white",
  "Packaged Foods": "from-orange-600 to-amber-600 text-white",
  "Spices & Seasonings": "from-red-700 to-orange-700 text-white",
  "Bakery Items": "from-yellow-600 to-orange-600 text-white",
  "Frozen Foods": "from-cyan-600 to-blue-600 text-white",
  Seafood: "from-teal-600 to-cyan-600 text-white",
  "Grains & Cereals": "from-amber-600 to-yellow-600 text-white",
  "Oils & Condiments": "from-lime-600 to-green-600 text-white",
  "Snacks & Confectionery": "from-pink-600 to-rose-600 text-white",
  "Organic Products": "from-green-700 to-lime-700 text-white",
  "International Foods": "from-indigo-600 to-purple-600 text-white",
}

const reviewComments = [
  "Excellent quality products and reliable delivery. Been working with them for 2 years!",
  "Great prices for bulk orders. Perfect for my food truck business.",
  "Fresh ingredients every time. My customers love the quality.",
  "Professional service and always on time with deliveries.",
  "Wide variety of products and competitive pricing.",
  "Outstanding customer service. They really understand street food vendors.",
  "Consistent quality and fair prices. Highly recommend!",
  "Been my go-to supplier for 3 years. Never disappointed.",
  "Great for small businesses. Flexible order quantities.",
  "Top-notch products and excellent communication.",
  "Reliable partner for my food stall. Quality is always consistent.",
  "Best wholesale prices in the area. Great for budget-conscious vendors.",
  "Fresh produce delivered daily. Perfect for my juice bar.",
  "Professional team that understands the food service industry.",
  "Quality ingredients at wholesale prices. Exactly what I needed.",
  "Fast delivery and excellent customer support.",
  "Premium quality at competitive wholesale rates.",
  "Flexible payment terms and great bulk discounts.",
  "Always fresh stock and reliable supply chain.",
  "Perfect for street food vendors - they get our needs!",
]

const vendorNames = [
  "Maria's Tacos",
  "Tony's Pizza",
  "Sam's Burgers",
  "Lisa's Smoothies",
  "Mike's BBQ",
  "Anna's Dumplings",
  "Carlos's Burritos",
  "Jenny's Salads",
  "David's Hot Dogs",
  "Sarah's Sandwiches",
  "Ahmed's Kebabs",
  "Rosa's Empanadas",
  "Kevin's Wings",
  "Nina's Noodles",
  "Frank's Fries",
  "Priya's Curry",
  "Chen's Dumplings",
  "Marco's Pasta",
  "Fatima's Falafel",
  "Jose's Quesadillas",
  "Kim's Korean BBQ",
  "Raj's Samosas",
  "Elena's Empanadas",
  "Omar's Shawarma",
  "Yuki's Sushi",
  "Giovanni's Gelato",
  "Amara's Injera",
  "Diego's Churros",
  "Mei's Bao",
  "Hassan's Hummus",
]

const lucknowAreas = [
  "Hazratganj",
  "Gomti Nagar",
  "Aminabad",
  "Chowk",
  "Alambagh",
  "Indira Nagar",
  "Mahanagar",
  "Aliganj",
  "Rajajipuram",
  "Vikas Nagar",
  "Ashiyana",
  "Jankipuram",
  "Telibagh",
  "Chinhat",
  "Faizabad Road",
  "Kanpur Road",
  "Hardoi Road",
  "Sitapur Road",
  "Raebareli Road",
  "IIM Road",
  "Ring Road",
  "Shaheed Path",
  "Kursi Road",
  "Amausi",
  "Bakshi Ka Talab",
  "Vrindavan Yojana",
  "Eldeco",
  "Omaxe City",
  "Sushant Golf City",
  "La Residentia",
]

const businessSuffixes = [
  "Wholesale Center",
  "Distribution Hub",
  "Supply Point",
  "Market Place",
  "Trade Center",
  "Commercial Complex",
  "Business Park",
  "Industrial Area",
  "Supply Chain Center",
  "Wholesale Market",
]

function generateReviews(supplierId: number, count: number) {
  const reviews = []
  for (let i = 0; i < count; i++) {
    const rating =
      Math.random() > 0.8 ? 5 : Math.random() > 0.6 ? 4 : Math.random() > 0.4 ? 3 : Math.random() > 0.2 ? 2 : 1
    const daysAgo = Math.floor(Math.random() * 90) + 1
    const date = new Date()
    date.setDate(date.getDate() - daysAgo)

    reviews.push({
      id: i + 1,
      user: vendorNames[Math.floor(Math.random() * vendorNames.length)],
      rating,
      comment: reviewComments[Math.floor(Math.random() * reviewComments.length)],
      date: date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    })
  }
  return reviews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

function generateSupplier(id: number) {
  // Use ID as seed for consistent generation
  const nameIndex = (id - 1) % supplierNames.length
  const categoryIndex = (id - 1) % categories.length
  const category = categories[categoryIndex]

  // Generate consistent location around Lucknow
  const baseLatLng = { lat: 26.8467, lng: 80.9462 }
  const radiusInDegrees = 0.1 // ~11km radius
  const angle = (id * 137.5) % 360 // Golden angle for good distribution
  const distance = ((id % 20) / 20) * radiusInDegrees

  const lat = baseLatLng.lat + distance * Math.cos((angle * Math.PI) / 180)
  const lng = baseLatLng.lng + distance * Math.sin((angle * Math.PI) / 180)

  // Generate address
  const streetNumber = 100 + ((id * 17) % 9900)
  const area = lucknowAreas[(id - 1) % lucknowAreas.length]
  const suffix = id % 3 === 0 ? businessSuffixes[(id - 1) % businessSuffixes.length] : null
  const unitNumber = id % 4 === 0 ? `Suite ${100 + ((id * 7) % 900)}` : null

  let address = `${streetNumber} ${area}`
  if (unitNumber) address += `, ${unitNumber}`
  if (suffix) address += `, ${suffix}`
  address += `, Lucknow, Uttar Pradesh`

  // Generate rating (weighted towards higher ratings)
  const ratingBase = 3.5 + (Math.sin(id * 0.1) + 1) * 0.75 // 3.5 to 5.0
  const rating = Math.round(ratingBase * 10) / 10

  const reviewCount = 25 + ((id * 13) % 200)
  const reviews = generateReviews(id, Math.min(reviewCount, 15))

  const descriptions = [
    `Premium wholesale supplier specializing in ${category.toLowerCase()} for street food vendors and restaurants. We pride ourselves on quality, freshness, and competitive pricing.`,
    `Family-owned wholesale business serving the Lucknow area for over ${5 + (id % 20)} years. Specializing in ${category.toLowerCase()} with same-day delivery available.`,
    `Leading distributor of ${category.toLowerCase()} with a focus on supporting local food entrepreneurs. Bulk pricing and flexible payment terms available.`,
    `Trusted wholesale partner for ${category.toLowerCase()}. We understand the unique needs of street food vendors and offer customized solutions.`,
    `Professional food service distributor specializing in ${category.toLowerCase()}. Quality guaranteed with competitive wholesale pricing and reliable delivery.`,
  ]

  return {
    id,
    name: supplierNames[nameIndex],
    category,
    rating,
    reviewCount,
    description: descriptions[(id - 1) % descriptions.length],
    location: { lat, lng, address },
    reviews,
    icon: categoryIcons[category] || "🏪",
  }
}

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  reviews: Array<{
    id: number
    user: string
    rating: number
    comment: string
    date: string
  }>
  icon: string
}

export default function SupplierDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [supplier, setSupplier] = useState<Supplier | null>(null)
  const [loading, setLoading] = useState(true)
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)

  useEffect(() => {
    // Get supplier ID from params
    const supplierId = params?.id ? Number.parseInt(params.id as string) : null

    console.log("Supplier ID from params:", supplierId)

    if (supplierId && supplierId >= 1 && supplierId <= 100) {
      // Generate supplier data for this ID
      const generatedSupplier = generateSupplier(supplierId)
      console.log("Generated supplier:", generatedSupplier.name)
      setSupplier(generatedSupplier)
    } else {
      console.log("Invalid supplier ID:", supplierId)
    }

    setLoading(false)
  }, [params])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center space-y-6">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-gradient-to-r from-orange-500/20 to-red-500/20"></div>
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-gradient-to-r from-orange-500 to-red-500 border-t-transparent absolute top-0"></div>
          </div>
          <div className="text-slate-600 dark:text-slate-400 font-medium text-lg">Loading supplier details...</div>
          <div className="w-48 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-orange-500 to-red-500 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!supplier) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center p-4">
        <Card className="max-w-lg mx-auto shadow-2xl border-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl">
          <CardHeader className="text-center pb-4">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-800 dark:text-slate-200">Supplier Not Found</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-400 text-base leading-relaxed">
              The supplier you're looking for doesn't exist in our database.
              <div className="mt-3 p-3 bg-slate-100 dark:bg-slate-800 rounded-lg text-sm">
                <div className="font-medium text-slate-700 dark:text-slate-300">Valid Range: IDs 1-100</div>
                <div className="text-slate-500 dark:text-slate-500">Requested: {params?.id}</div>
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              <Button
                onClick={() => router.push("/")}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Map
              </Button>
              <Button
                variant="outline"
                onClick={() => window.location.reload()}
                className="w-full border-2 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 py-3 rounded-xl transition-all duration-300"
              >
                Refresh Page
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const ratingDistribution = [
    { stars: 5, count: Math.floor(supplier.reviewCount * 0.6), percentage: 60 },
    { stars: 4, count: Math.floor(supplier.reviewCount * 0.25), percentage: 25 },
    { stars: 3, count: Math.floor(supplier.reviewCount * 0.1), percentage: 10 },
    { stars: 2, count: Math.floor(supplier.reviewCount * 0.03), percentage: 3 },
    { stars: 1, count: Math.floor(supplier.reviewCount * 0.02), percentage: 2 },
  ]

  const categoryColorClass = categoryColors[supplier.category] || "from-slate-600 to-slate-700 text-white"

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      {/* Enhanced Header with Glassmorphism */}
      <div className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-red-500/5 to-pink-500/10"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(251,146,60,0.1),transparent_50%)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(251,146,60,0.05),transparent_50%)]"></div>

        <div className="relative backdrop-blur-sm border-b border-white/20 dark:border-slate-800/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Button
              variant="ghost"
              onClick={() => router.push("/")}
              className="mb-8 hover:bg-white/20 dark:hover:bg-slate-800/50 backdrop-blur-sm border border-white/10 dark:border-slate-700/50 rounded-xl px-6 py-3 transition-all duration-300 group"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform duration-300" />
              <span className="font-medium">Back to Map</span>
            </Button>

            <div className="flex flex-col lg:flex-row items-start space-y-8 lg:space-y-0 lg:space-x-12">
              {/* Enhanced Supplier Icon */}
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all duration-500"></div>
                <div className="relative w-32 h-32 bg-gradient-to-br from-white to-gray-50 dark:from-slate-800 dark:to-slate-700 backdrop-blur-xl border-2 border-white/20 dark:border-slate-700/50 rounded-3xl flex items-center justify-center shadow-2xl group-hover:scale-105 transition-all duration-500">
                  <span className="text-6xl drop-shadow-lg">{supplier.icon}</span>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                    <Verified className="w-4 h-4 text-white" />
                  </div>
                </div>
              </div>

              {/* Enhanced Supplier Info */}
              <div className="flex-1 space-y-6">
                <div>
                  <h1 className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 dark:from-slate-200 dark:via-slate-100 dark:to-slate-200 bg-clip-text text-transparent mb-4 leading-tight">
                    {supplier.name}
                  </h1>

                  <div className="flex flex-wrap items-center gap-3 mb-6">
                    <Badge
                      className={`bg-gradient-to-r ${categoryColorClass} border-0 px-4 py-2 text-sm font-bold rounded-full shadow-lg`}
                    >
                      <span className="mr-2">{supplier.icon}</span>
                      {supplier.category}
                    </Badge>
                    <Badge className="bg-gradient-to-r from-green-600 to-emerald-600 text-white border-0 px-4 py-2 text-sm font-bold rounded-full shadow-lg">
                      <Shield className="w-4 h-4 mr-2" />
                      Verified #{supplier.id}
                    </Badge>
                    <Badge className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white border-0 px-4 py-2 text-sm font-bold rounded-full shadow-lg">
                      <Calendar className="w-4 h-4 mr-2" />
                      Est. {2024 - (supplier.id % 15)}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Rating Card */}
                  <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-2xl p-6 border border-white/20 dark:border-slate-700/50 shadow-xl">
                    <div className="flex items-center space-x-4 mb-3">
                      <div className="flex items-center space-x-2">
                        <div className="relative">
                          <Star className="w-10 h-10 fill-yellow-400 text-yellow-400 drop-shadow-lg" />
                          <div className="absolute inset-0 bg-yellow-400/20 rounded-full blur-lg"></div>
                        </div>
                        <span className="text-4xl font-bold text-slate-800 dark:text-slate-200">{supplier.rating}</span>
                      </div>
                      <div className="text-slate-700 dark:text-slate-300">
                        <div className="text-lg font-semibold">Excellent</div>
                        <div className="text-sm">({supplier.reviewCount} reviews)</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                      <MessageCircle className="w-4 h-4" />
                      <span>Based on verified vendor reviews</span>
                    </div>
                  </div>

                  {/* Location Card */}
                  <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-2xl p-6 border border-white/20 dark:border-slate-700/50 shadow-xl">
                    <div className="flex items-start space-x-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                        <MapPin className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold text-slate-800 dark:text-slate-200 mb-1">Location</div>
                        <div className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed">
                          {supplier.location.address}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Book Now Button */}
                <div className="pt-4">
                  <Button
                    onClick={() => setIsBookingModalOpen(true)}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold text-lg px-8 py-4 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 group"
                  >
                    <ShoppingCart className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform duration-300" />
                    Book Products Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Content Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="overview" className="w-full">
          {/* Enhanced Tab Navigation */}
          <TabsList className="grid w-full grid-cols-3 mb-12 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 rounded-2xl p-2 shadow-xl">
            <TabsTrigger
              value="overview"
              className="text-lg py-4 rounded-xl font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300"
            >
              <Award className="w-5 h-5 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="text-lg py-4 rounded-xl font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Reviews
            </TabsTrigger>
            <TabsTrigger
              value="contact"
              className="text-lg py-4 rounded-xl font-semibold data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all duration-300"
            >
              <Phone className="w-5 h-5 mr-2" />
              Contact
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* About Section */}
            <Card className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-slate-50/80 to-white/80 dark:from-slate-800/80 dark:to-slate-900/80 border-b border-white/20 dark:border-slate-700/50">
                <CardTitle className="flex items-center space-x-3 text-2xl font-bold text-slate-800 dark:text-slate-200">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <span>About This Supplier</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-lg mb-8 font-medium">
                  {supplier.description}
                </p>

                {/* Enhanced Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl"></div>
                    <div className="relative text-center p-8 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-500 shadow-lg hover:shadow-xl">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Users className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-4xl font-bold text-slate-800 dark:text-slate-200 mb-2">
                        {supplier.reviewCount}
                      </div>
                      <div className="text-slate-700 dark:text-slate-300 font-medium">Happy Vendors</div>
                    </div>
                  </div>

                  <div className="group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 rounded-2xl"></div>
                    <div className="relative text-center p-8 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-500 shadow-lg hover:shadow-xl">
                      <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Star className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-4xl font-bold text-slate-800 dark:text-slate-200 mb-2">
                        {supplier.rating}
                      </div>
                      <div className="text-slate-700 dark:text-slate-300 font-medium">Average Rating</div>
                    </div>
                  </div>

                  <div className="group relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-2xl"></div>
                    <div className="relative text-center p-8 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-500 shadow-lg hover:shadow-xl">
                      <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <TrendingUp className="w-8 h-8 text-white" />
                      </div>
                      <div className="text-4xl font-bold text-slate-800 dark:text-slate-200 mb-2">98%</div>
                      <div className="text-slate-700 dark:text-slate-300 font-medium">Satisfaction Rate</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Rating Breakdown */}
            <Card className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-slate-50/80 to-white/80 dark:from-slate-800/80 dark:to-slate-900/80 border-b border-white/20 dark:border-slate-700/50">
                <CardTitle className="text-2xl font-bold text-slate-800 dark:text-slate-200">
                  Rating Breakdown
                </CardTitle>
                <CardDescription className="text-slate-700 dark:text-slate-300">
                  Detailed analysis of customer ratings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                {ratingDistribution.map((item) => (
                  <div key={item.stars} className="flex items-center space-x-6 group">
                    <div className="flex items-center space-x-3 w-24">
                      <span className="font-bold text-slate-800 dark:text-slate-200">{item.stars}</span>
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400 drop-shadow-sm" />
                    </div>
                    <div className="flex-1 relative">
                      <Progress
                        value={item.percentage}
                        className="h-4 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden shadow-inner"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <div className="w-16 text-right">
                      <span className="text-slate-700 dark:text-slate-300 font-semibold">{item.count}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-3xl font-bold text-slate-800 dark:text-slate-200">Customer Reviews</h3>
              <Badge className="bg-gradient-to-r from-orange-600 to-red-600 text-white border-0 px-6 py-3 text-lg font-bold rounded-full shadow-lg">
                {supplier.reviews.length} recent reviews
              </Badge>
            </div>

            <div className="space-y-6">
              {supplier.reviews.map((review, index) => (
                <Card
                  key={review.id}
                  className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 shadow-xl hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group hover:scale-[1.02]"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <CardContent className="p-8">
                    <div className="flex items-start space-x-6">
                      <div className="relative">
                        <Avatar className="w-16 h-16 shadow-xl ring-4 ring-white/20 dark:ring-slate-700/50">
                          <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-500 text-white font-bold text-xl">
                            {review.user.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                          <Verified className="w-3 h-3 text-white" />
                        </div>
                      </div>

                      <div className="flex-1 space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <span className="font-bold text-xl text-slate-800 dark:text-slate-200">{review.user}</span>
                            <div className="flex items-center space-x-1">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-5 h-5 transition-all duration-300 ${
                                    i < review.rating
                                      ? "fill-yellow-400 text-yellow-400 drop-shadow-sm"
                                      : "text-slate-300 dark:text-slate-600"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 text-slate-600 dark:text-slate-400">
                            <Clock className="w-4 h-4" />
                            <span className="text-sm font-medium">{review.date}</span>
                          </div>
                        </div>

                        <div className="relative">
                          <Quote className="w-8 h-8 text-orange-500/30 absolute -top-2 -left-2" />
                          <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-lg pl-6 font-medium">
                            {review.comment}
                          </p>
                        </div>

                        <div className="flex items-center space-x-4 pt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="hover:bg-orange-500/10 hover:text-orange-600 dark:hover:text-orange-400 rounded-xl px-4 py-2 transition-all duration-300 group/btn"
                          >
                            <ThumbsUp className="w-4 h-4 mr-2 group-hover/btn:scale-110 transition-transform duration-300" />
                            <span className="font-medium">Helpful</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="contact" className="space-y-8">
            <Card className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-white/20 dark:border-slate-700/50 shadow-2xl rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-slate-50/80 to-white/80 dark:from-slate-800/80 dark:to-slate-900/80 border-b border-white/20 dark:border-slate-700/50">
                <CardTitle className="text-3xl font-bold text-slate-800 dark:text-slate-200">
                  Contact Information
                </CardTitle>
                <CardDescription className="text-lg text-slate-700 dark:text-slate-300">
                  Get in touch with this verified supplier
                </CardDescription>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                {/* Contact Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="group relative overflow-hidden rounded-2xl">
                    <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-orange-500/10"></div>
                    <div className="relative flex items-center space-x-4 p-6 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-300 shadow-lg">
                      <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-1">Address</div>
                        <div className="text-slate-700 dark:text-slate-300 leading-relaxed">
                          {supplier.location.address}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="group relative overflow-hidden rounded-2xl">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-500/10"></div>
                    <div className="relative flex items-center space-x-4 p-6 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-300 shadow-lg">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-1">Phone</div>
                        <div className="text-slate-700 dark:text-slate-300">+91 {9000000000 + supplier.id}</div>
                      </div>
                    </div>
                  </div>

                  <div className="group relative overflow-hidden rounded-2xl">
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10"></div>
                    <div className="relative flex items-center space-x-4 p-6 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-300 shadow-lg">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg">
                        <Globe className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-1">Website</div>
                        <div className="text-slate-700 dark:text-slate-300">
                          www.{supplier.name.toLowerCase().replace(/[^a-z0-9]/g, "")}.com
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="group relative overflow-hidden rounded-2xl">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-violet-500/10"></div>
                    <div className="relative flex items-center space-x-4 p-6 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm border border-white/20 dark:border-slate-700/50 hover:scale-105 transition-all duration-300 shadow-lg">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-violet-500 rounded-xl flex items-center justify-center shadow-lg">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-1">Business Hours</div>
                        <div className="text-slate-700 dark:text-slate-300">
                          <div>Mon-Fri: 8:00 AM - 6:00 PM</div>
                          <div>Sat: 9:00 AM - 4:00 PM</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Action Buttons */}
                <div className="pt-8 space-y-4">
                  <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold text-lg py-6 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 group">
                    <Phone className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform duration-300" />
                    Call Now
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-2 border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold text-lg py-6 rounded-2xl transition-all duration-300 group bg-transparent"
                  >
                    <Globe className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform duration-300" />
                    Visit Website
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Booking Modal */}
      {supplier && (
        <BookingModal isOpen={isBookingModalOpen} onClose={() => setIsBookingModalOpen(false)} supplier={supplier} />
      )}
    </div>
  )
}
