# Supplier Review App - Deployment Guide

## 🚀 Quick Deployment Options

### Option 1: Vercel (Recommended)
1. **Create Vercel Account**: Go to [vercel.com](https://vercel.com)
2. **Import Project**: Click "New Project" → Import from Git
3. **Connect Repository**: Link your GitHub/GitLab repository
4. **Deploy**: Vercel auto-detects Next.js and deploys instantly

### Option 2: Netlify
1. **Create Netlify Account**: Go to [netlify.com](https://netlify.com)
2. **New Site**: Click "New site from Git"
3. **Connect Repository**: Choose your Git provider
4. **Build Settings**: 
   - Build command: `npm run build`
   - Publish directory: `.next`

### Option 3: Railway
1. **Create Railway Account**: Go to [railway.app](https://railway.app)
2. **New Project**: Click "New Project" → "Deploy from GitHub repo"
3. **Select Repository**: Choose your supplier review app repo
4. **Auto Deploy**: Railway handles the rest automatically

## 🔧 Common Issues & Solutions

### "Failed to create repo" Error
This usually happens due to:

1. **Repository Name Conflicts**
   - Try a different repository name
   - Use lowercase letters and hyphens only
   - Example: `supplier-review-app-v2`

2. **Git Authentication Issues**
   \`\`\`bash
   # Re-authenticate with GitHub
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   \`\`\`

3. **Large File Issues**
   - Remove node_modules before pushing
   - Add proper .gitignore file
   - Use Git LFS for large assets

### Build Errors
1. **Missing Dependencies**
   \`\`\`bash
   npm install
   npm run build
   \`\`\`

2. **TypeScript Errors**
   - Check all imports are correct
   - Ensure all components are properly typed

3. **Environment Variables**
   - Add required env vars in deployment platform
   - Use NEXT_PUBLIC_ prefix for client-side vars

## 📋 Pre-Deployment Checklist

- [ ] All components import correctly
- [ ] No TypeScript errors
- [ ] App builds successfully locally (`npm run build`)
- [ ] All images and assets are included
- [ ] Environment variables configured
- [ ] Repository is public or deployment platform has access

## 🌐 Environment Variables (if needed)

\`\`\`env
# Add these to your deployment platform
NEXT_PUBLIC_APP_URL=https://your-app-domain.com
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-supabase-key
\`\`\`

## 📱 Testing Your Deployment

1. **Functionality Test**
   - Navigate to different supplier pages
   - Test booking modal
   - Check responsive design

2. **Performance Test**
   - Use Google PageSpeed Insights
   - Check loading times
   - Verify mobile experience

## 🆘 Need Help?

If you're still having issues:
1. Check the deployment platform's logs
2. Verify all files are included in your repository
3. Test the build process locally first
4. Contact support for your chosen platform

## 🎯 Success Indicators

Your deployment is successful when:
- ✅ App loads without errors
- ✅ All supplier pages work (try /supplier/1, /supplier/18, etc.)
- ✅ Booking modal opens and functions
- ✅ Responsive design works on mobile
- ✅ Dark/light mode toggle works
