-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create bookings table
CREATE TABLE IF NOT EXISTS public.bookings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    supplier_id INTEGER NOT NULL,
    supplier_name TEXT NOT NULL,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    business_name TEXT,
    product_category TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit TEXT NOT NULL,
    estimated_budget DECIMAL(10,2),
    delivery_date DATE NOT NULL,
    delivery_address TEXT NOT NULL,
    special_requirements TEXT,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_supplier_id ON public.bookings(supplier_id);
CREATE INDEX IF NOT EXISTS idx_bookings_customer_email ON public.bookings(customer_email);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON public.bookings(created_at);
CREATE INDEX IF NOT EXISTS idx_bookings_delivery_date ON public.bookings(delivery_date);

-- Enable Row Level Security
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Create policies for Row Level Security
CREATE POLICY "Enable read access for all users" ON public.bookings
    FOR SELECT USING (true);

CREATE POLICY "Enable insert for all users" ON public.bookings
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON public.bookings
    FOR UPDATE USING (true);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_bookings_updated_at 
    BEFORE UPDATE ON public.bookings 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Insert some sample data for testing
INSERT INTO public.bookings (
    supplier_id, supplier_name, customer_name, customer_email, customer_phone,
    business_name, product_category, quantity, unit, estimated_budget,
    delivery_date, delivery_address, special_requirements, status
) VALUES 
(1, 'Fresh Valley Wholesale', 'John Doe', 'john@example.com', '+91 9876543210',
 'John''s Food Truck', 'Fresh Produce', 50, 'kg', 2500.00,
 CURRENT_DATE + INTERVAL '3 days', '123 Main Street, Lucknow, UP', 'Need early morning delivery', 'pending'),
(2, 'Metro Food Distributors', 'Jane Smith', 'jane@example.com', '+91 9876543211',
 'Jane''s Restaurant', 'Meat & Poultry', 25, 'kg', 5000.00,
 CURRENT_DATE + INTERVAL '5 days', '456 Oak Avenue, Lucknow, UP', 'Halal certified required', 'confirmed'),
(3, 'Golden Harvest Supply', 'Mike Johnson', 'mike@example.com', '+91 9876543212',
 'Mike''s Cafe', 'Dairy Products', 100, 'liters', 3000.00,
 CURRENT_DATE + INTERVAL '2 days', '789 Pine Road, Lucknow, UP', NULL, 'pending');

-- Create a view for booking statistics
CREATE OR REPLACE VIEW booking_stats AS
SELECT 
    supplier_id,
    supplier_name,
    COUNT(*) as total_bookings,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_bookings,
    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed_bookings,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_bookings,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_bookings,
    AVG(estimated_budget) as avg_order_value,
    SUM(estimated_budget) as total_revenue
FROM public.bookings
GROUP BY supplier_id, supplier_name
ORDER BY total_bookings DESC;

-- Grant necessary permissions
GRANT ALL ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO anon;
GRANT SELECT ON booking_stats TO authenticated;
GRANT SELECT ON booking_stats TO anon;
