interface Review {
  id: number
  user: string
  rating: number
  comment: string
  date: string
}

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  reviews: Review[]
  icon: string
}

const supplierNames = [
  "Fresh Valley Wholesale",
  "Metro Food Distributors",
  "Golden Harvest Supply",
  "Urban Kitchen Partners",
  "Prime Ingredients Co.",
  "Street Food Central",
  "Quality Provisions Inc.",
  "Wholesale Food Hub",
  "City Market Suppliers",
  "Fresh Direct Wholesale",
  "Gourmet Supply Chain",
  "Local Harvest Distributors",
  "Food Service Partners",
  "Bulk Buy Specialists",
  "Restaurant Supply Co.",
  "Wholesale Kitchen Solutions",
  "Farm Fresh Distributors",
  "Commercial Food Supply",
  "Vendor Support Network",
  "Street Eats Wholesale",
]

const categories = [
  "Fresh Produce",
  "Meat & Poultry",
  "Dairy Products",
  "Beverages",
  "Packaged Foods",
  "Spices & Seasonings",
  "Bakery Items",
  "Frozen Foods",
]

// Icons for different supplier categories
const categoryIcons: Record<string, string> = {
  "Fresh Produce": "🥬",
  "Meat & Poultry": "🥩",
  "Dairy Products": "🥛",
  Beverages: "🥤",
  "Packaged Foods": "📦",
  "Spices & Seasonings": "🌶️",
  "Bakery Items": "🥖",
  "Frozen Foods": "🧊",
}

const reviewComments = [
  "Excellent quality products and reliable delivery. Been working with them for 2 years!",
  "Great prices for bulk orders. Perfect for my food truck business.",
  "Fresh ingredients every time. My customers love the quality.",
  "Professional service and always on time with deliveries.",
  "Wide variety of products and competitive pricing.",
  "Outstanding customer service. They really understand street food vendors.",
  "Consistent quality and fair prices. Highly recommend!",
  "Been my go-to supplier for 3 years. Never disappointed.",
  "Great for small businesses. Flexible order quantities.",
  "Top-notch products and excellent communication.",
  "Reliable partner for my food stall. Quality is always consistent.",
  "Best wholesale prices in the area. Great for budget-conscious vendors.",
  "Fresh produce delivered daily. Perfect for my juice bar.",
  "Professional team that understands the food service industry.",
  "Quality ingredients at wholesale prices. Exactly what I needed.",
]

const vendorNames = [
  "Maria's Tacos",
  "Tony's Pizza",
  "Sam's Burgers",
  "Lisa's Smoothies",
  "Mike's BBQ",
  "Anna's Dumplings",
  "Carlos's Burritos",
  "Jenny's Salads",
  "David's Hot Dogs",
  "Sarah's Sandwiches",
  "Ahmed's Kebabs",
  "Rosa's Empanadas",
  "Kevin's Wings",
  "Nina's Noodles",
  "Frank's Fries",
]

// Enhanced street names by major cities and regions
const streetNamesByRegion: Record<string, string[]> = {
  default: [
    "Main Street",
    "Broadway",
    "Market Street",
    "First Avenue",
    "Oak Street",
    "Park Avenue",
    "Washington Street",
    "Lincoln Avenue",
    "Elm Street",
    "Maple Avenue",
    "Cedar Street",
    "Pine Street",
    "Walnut Street",
    "Cherry Avenue",
    "Sunset Boulevard",
    "Industrial Boulevard",
    "Commerce Drive",
    "Business Park Way",
    "Warehouse District",
    "Distribution Center Drive",
    "Supply Chain Avenue",
    "Wholesale Way",
    "Trade Street",
  ],
  // Indian Cities
  Lucknow: [
    "Hazratganj",
    "Gomti Nagar",
    "Aminabad",
    "Chowk",
    "Alambagh",
    "Indira Nagar",
    "Mahanagar",
    "Aliganj",
    "Rajajipuram",
    "Vikas Nagar",
    "Ashiyana",
    "Jankipuram",
    "Telibagh",
    "Chinhat",
    "Faizabad Road",
    "Kanpur Road",
    "Hardoi Road",
    "Sitapur Road",
    "Raebareli Road",
    "IIM Road",
    "Ring Road",
    "Shaheed Path",
    "Kursi Road",
    "Amausi",
    "Bakshi Ka Talab",
  ],
  Mumbai: [
    "Marine Drive",
    "Linking Road",
    "Hill Road",
    "S.V. Road",
    "Western Express Highway",
    "Eastern Express Highway",
    "Pedder Road",
    "Worli Sea Face",
    "Juhu Tara Road",
    "Carter Road",
    "Turner Road",
    "Pali Hill",
    "Union Park",
    "Lokhandwala",
    "Andheri Kurla Road",
    "Mahakali Caves Road",
    "Saki Naka",
    "Powai",
    "Hiranandani",
    "Ghatkopar",
    "Mulund",
    "Thane",
    "Navi Mumbai",
    "Vashi",
    "Nerul",
  ],
  Delhi: [
    "Connaught Place",
    "Rajpath",
    "India Gate",
    "Chandni Chowk",
    "Karol Bagh",
    "Lajpat Nagar",
    "Khan Market",
    "Defence Colony",
    "Greater Kailash",
    "Vasant Vihar",
    "Hauz Khas",
    "Saket",
    "Nehru Place",
    "Laxmi Nagar",
    "Preet Vihar",
    "Mayur Vihar",
    "Patparganj",
    "Shahdara",
    "Model Town",
    "Civil Lines",
    "Daryaganj",
    "Paharganj",
    "Janpath",
    "Ashram",
    "Ring Road",
  ],
  Bangalore: [
    "MG Road",
    "Brigade Road",
    "Commercial Street",
    "Residency Road",
    "Richmond Road",
    "Cunningham Road",
    "Lavelle Road",
    "St. Marks Road",
    "Church Street",
    "Infantry Road",
    "Kasturba Road",
    "Cubbon Road",
    "Vittal Mallya Road",
    "UB City Mall",
    "Koramangala",
    "Indiranagar",
    "Jayanagar",
    "Basavanagudi",
    "Malleshwaram",
    "Rajajinagar",
    "Whitefield",
    "Electronic City",
    "Hebbal",
    "Yeshwantpur",
    "Banashankari",
  ],
  Chennai: [
    "Anna Salai",
    "T. Nagar",
    "Pondy Bazaar",
    "Express Avenue",
    "Marina Beach Road",
    "ECR Road",
    "OMR Road",
    "GST Road",
    "Poonamallee High Road",
    "Mount Road",
    "Nungambakkam High Road",
    "Cathedral Road",
    "Khader Nawaz Khan Road",
    "Dr. Radhakrishnan Salai",
    "Eldams Road",
    "Cenotaph Road",
    "Harrington Road",
    "Whites Road",
    "Lloyds Road",
    "Greenways Road",
    "Adyar",
    "Velachery",
    "Tambaram",
    "Chrompet",
    "Pallavaram",
  ],
  Kolkata: [
    "Park Street",
    "Camac Street",
    "Chowringhee",
    "Esplanade",
    "Dalhousie Square",
    "College Street",
    "Shyama Charan Street",
    "Lenin Sarani",
    "Jawaharlal Nehru Road",
    "Rashbehari Avenue",
    "Gariahat Road",
    "Southern Avenue",
    "Ballygunge Circular Road",
    "Elgin Road",
    "Theatre Road",
    "Free School Street",
    "Russell Street",
    "Loudon Street",
    "Middleton Street",
    "Hindustan Road",
    "Salt Lake",
    "New Town",
    "Rajarhat",
    "Howrah",
    "Sealdah",
  ],
  Hyderabad: [
    "Banjara Hills",
    "Jubilee Hills",
    "HITEC City",
    "Gachibowli",
    "Madhapur",
    "Kondapur",
    "Kukatpally",
    "Miyapur",
    "Secunderabad",
    "Begumpet",
    "Somajiguda",
    "Ameerpet",
    "SR Nagar",
    "Punjagutta",
    "Lakdi Ka Pul",
    "Abids",
    "Nampally",
    "Koti",
    "Dilsukhnagar",
    "LB Nagar",
    "Uppal",
    "Kompally",
    "Bachupally",
    "Nizampet",
    "Chandanagar",
  ],
  Pune: [
    "FC Road",
    "JM Road",
    "MG Road",
    "Koregaon Park",
    "Camp",
    "Shivajinagar",
    "Deccan",
    "Kothrud",
    "Karve Nagar",
    "Warje",
    "Baner",
    "Aundh",
    "Viman Nagar",
    "Kharadi",
    "Hadapsar",
    "Magarpatta",
    "Hinjewadi",
    "Wakad",
    "Pimpri",
    "Chinchwad",
    "Nigdi",
    "Akurdi",
    "Bhosari",
    "Chakan",
    "Talegaon",
  ],
  // US Cities
  "New York": [
    "Broadway",
    "Madison Avenue",
    "Park Avenue",
    "Lexington Avenue",
    "Third Avenue",
    "Second Avenue",
    "First Avenue",
    "York Avenue",
    "East Houston Street",
    "Canal Street",
    "Spring Street",
    "Broome Street",
    "Grand Street",
    "Delancey Street",
    "Rivington Street",
    "Orchard Street",
    "Essex Street",
    "Ludlow Street",
    "Clinton Street",
    "Suffolk Street",
  ],
  "Los Angeles": [
    "Sunset Boulevard",
    "Hollywood Boulevard",
    "Melrose Avenue",
    "Beverly Boulevard",
    "Wilshire Boulevard",
    "Santa Monica Boulevard",
    "Ventura Boulevard",
    "Sepulveda Boulevard",
    "La Brea Avenue",
    "Fairfax Avenue",
    "Western Avenue",
    "Vermont Avenue",
    "Normandie Avenue",
    "Hoover Street",
    "Figueroa Street",
  ],
  Chicago: [
    "Michigan Avenue",
    "State Street",
    "LaSalle Street",
    "Wabash Avenue",
    "Clark Street",
    "Dearborn Street",
    "Wells Street",
    "Franklin Street",
    "Lake Street",
    "Randolph Street",
    "Washington Street",
    "Madison Street",
    "Monroe Street",
    "Adams Street",
    "Jackson Boulevard",
  ],
  // UK Cities
  London: [
    "Oxford Street",
    "Regent Street",
    "Bond Street",
    "Piccadilly",
    "The Strand",
    "Fleet Street",
    "King's Road",
    "High Street Kensington",
    "Portobello Road",
    "Camden High Street",
    "Brick Lane",
    "Shoreditch High Street",
    "Old Street",
    "City Road",
    "Commercial Street",
    "Whitechapel Road",
    "Mile End Road",
    "Roman Road",
    "Bethnal Green Road",
    "Hackney Road",
  ],
}

// City name variations and aliases
const cityAliases: Record<string, string> = {
  NYC: "New York",
  LA: "Los Angeles",
  "Chi-town": "Chicago",
  "The Big Apple": "New York",
  "City of Angels": "Los Angeles",
  "Windy City": "Chicago",
  "Magic City": "Miami",
  "Space City": "Houston",
  "Valley of the Sun": "Phoenix",
  "City of Brotherly Love": "Philadelphia",
  "Alamo City": "San Antonio",
  "America's Finest City": "San Diego",
  "Big D": "Dallas",
  // Indian city aliases
  Bombay: "Mumbai",
  Calcutta: "Kolkata",
  Madras: "Chennai",
  Bengaluru: "Bangalore",
}

const businessSuffixes = ["Wholesale Center", "Distribution Hub", "Supply Point", "Market Place", "Trade Center"]

function generateReviews(count: number): Review[] {
  const reviews: Review[] = []

  for (let i = 0; i < count; i++) {
    const rating =
      Math.random() > 0.8 ? 5 : Math.random() > 0.6 ? 4 : Math.random() > 0.4 ? 3 : Math.random() > 0.2 ? 2 : 1
    const daysAgo = Math.floor(Math.random() * 90) + 1
    const date = new Date()
    date.setDate(date.getDate() - daysAgo)

    reviews.push({
      id: i + 1,
      user: vendorNames[Math.floor(Math.random() * vendorNames.length)],
      rating,
      comment: reviewComments[Math.floor(Math.random() * reviewComments.length)],
      date: date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
    })
  }

  return reviews.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

function generateLocalAddress(lat: number, lng: number, city: string, state: string): string {
  // Normalize city name and handle aliases
  const normalizedCity = cityAliases[city] || city

  // Get appropriate street names for the city
  const streetNames = streetNamesByRegion[normalizedCity] || streetNamesByRegion.default

  const streetNumber = Math.floor(Math.random() * 9999) + 1
  const streetName = streetNames[Math.floor(Math.random() * streetNames.length)]

  // Sometimes add a business suffix for wholesale suppliers (30% chance)
  const addBusinessSuffix = Math.random() > 0.7
  if (addBusinessSuffix) {
    const suffix = businessSuffixes[Math.floor(Math.random() * businessSuffixes.length)]
    return `${streetNumber} ${streetName}, ${suffix}, ${city}, ${state}`
  }

  // Add suite/unit numbers for some addresses (40% chance)
  const addUnit = Math.random() > 0.6
  if (addUnit) {
    const unitType = Math.random() > 0.5 ? "Suite" : "Unit"
    const unitNumber = Math.floor(Math.random() * 999) + 1
    return `${streetNumber} ${streetName}, ${unitType} ${unitNumber}, ${city}, ${state}`
  }

  return `${streetNumber} ${streetName}, ${city}, ${state}`
}

export function generateSuppliersNearLocation(
  centerLat: number,
  centerLng: number,
  city: string,
  state: string,
  count = 15,
): Supplier[] {
  const suppliers: Supplier[] = []
  const usedNames = new Set<string>()

  for (let i = 0; i < count; i++) {
    // Generate random location within ~5 mile radius
    const radiusInDegrees = 0.072 // Approximately 5 miles
    const angle = Math.random() * 2 * Math.PI
    const distance = Math.random() * radiusInDegrees

    const lat = centerLat + distance * Math.cos(angle)
    const lng = centerLng + distance * Math.sin(angle)

    // Select unique supplier name
    let name = supplierNames[Math.floor(Math.random() * supplierNames.length)]
    while (usedNames.has(name)) {
      name = supplierNames[Math.floor(Math.random() * supplierNames.length)]
    }
    usedNames.add(name)

    const category = categories[Math.floor(Math.random() * categories.length)]
    const reviewCount = Math.floor(Math.random() * 150) + 10
    const reviews = generateReviews(Math.min(reviewCount, 20))

    // Calculate weighted average rating
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0)
    const avgRating = reviews.length > 0 ? totalRating / reviews.length : 4.5
    const rating = Math.round(avgRating * 10) / 10

    const descriptions = [
      `Premium wholesale supplier specializing in ${category.toLowerCase()} for street food vendors and restaurants. We pride ourselves on quality, freshness, and competitive pricing.`,
      `Family-owned wholesale business serving the ${city} area for over 15 years. Specializing in ${category.toLowerCase()} with same-day delivery available.`,
      `Leading distributor of ${category.toLowerCase()} with a focus on supporting local food entrepreneurs. Bulk pricing and flexible payment terms available.`,
      `Trusted wholesale partner for ${category.toLowerCase()}. We understand the unique needs of street food vendors and offer customized solutions.`,
      `Professional food service distributor specializing in ${category.toLowerCase()}. Quality guaranteed with competitive wholesale pricing.`,
    ]

    suppliers.push({
      id: i + 1,
      name,
      category,
      rating,
      reviewCount,
      description: descriptions[Math.floor(Math.random() * descriptions.length)],
      location: {
        lat,
        lng,
        address: generateLocalAddress(lat, lng, city, state),
      },
      reviews,
      icon: categoryIcons[category] || "🏪",
    })
  }

  return suppliers.sort((a, b) => b.rating - a.rating)
}

// Create consistent mock suppliers that are always available
export const mockSuppliers: Supplier[] = [
  {
    id: 1,
    name: "Fresh Valley Wholesale",
    category: "Fresh Produce",
    rating: 4.8,
    reviewCount: 127,
    description:
      "Premium wholesale supplier specializing in fresh produce for street food vendors and restaurants. We pride ourselves on quality, freshness, and competitive pricing.",
    location: {
      lat: 26.8467,
      lng: 80.9462,
      address: "1247 Hazratganj, Wholesale Center, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "Maria's Tacos",
        rating: 5,
        comment: "Excellent quality products and reliable delivery. Been working with them for 2 years!",
        date: "Dec 15, 2024",
      },
      {
        id: 2,
        user: "Tony's Pizza",
        rating: 4,
        comment: "Great prices for bulk orders. Perfect for my food truck business.",
        date: "Dec 10, 2024",
      },
    ],
    icon: "🥬",
  },
  {
    id: 2,
    name: "Metro Food Distributors",
    category: "Meat & Poultry",
    rating: 4.6,
    reviewCount: 89,
    description:
      "Family-owned wholesale business serving the local area for over 15 years. Specializing in meat & poultry with same-day delivery available.",
    location: {
      lat: 26.8567,
      lng: 80.9362,
      address: "856 Gomti Nagar, Suite 302, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "Sam's Burgers",
        rating: 5,
        comment: "Fresh ingredients every time. My customers love the quality.",
        date: "Dec 12, 2024",
      },
      {
        id: 2,
        user: "Mike's BBQ",
        rating: 4,
        comment: "Professional service and always on time with deliveries.",
        date: "Dec 8, 2024",
      },
    ],
    icon: "🥩",
  },
  {
    id: 3,
    name: "Golden Harvest Supply",
    category: "Dairy Products",
    rating: 4.9,
    reviewCount: 156,
    description:
      "Leading distributor of dairy products with a focus on supporting local food entrepreneurs. Bulk pricing and flexible payment terms available.",
    location: {
      lat: 26.8367,
      lng: 80.9562,
      address: "432 Aminabad, Distribution Hub, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "Lisa's Smoothies",
        rating: 5,
        comment: "Wide variety of products and competitive pricing.",
        date: "Dec 14, 2024",
      },
      {
        id: 2,
        user: "Anna's Dumplings",
        rating: 5,
        comment: "Outstanding customer service. They really understand street food vendors.",
        date: "Dec 9, 2024",
      },
    ],
    icon: "🥛",
  },
  {
    id: 4,
    name: "Urban Kitchen Partners",
    category: "Beverages",
    rating: 4.7,
    reviewCount: 203,
    description:
      "Trusted wholesale partner for beverages. We understand the unique needs of street food vendors and offer customized solutions.",
    location: {
      lat: 26.8267,
      lng: 80.9662,
      address: "789 Chowk, Unit 45, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "Carlos's Burritos",
        rating: 5,
        comment: "Consistent quality and fair prices. Highly recommend!",
        date: "Dec 11, 2024",
      },
      {
        id: 2,
        user: "Jenny's Salads",
        rating: 4,
        comment: "Been my go-to supplier for 3 years. Never disappointed.",
        date: "Dec 7, 2024",
      },
    ],
    icon: "🥤",
  },
  {
    id: 5,
    name: "Prime Ingredients Co.",
    category: "Spices & Seasonings",
    rating: 4.5,
    reviewCount: 94,
    description:
      "Professional food service distributor specializing in spices & seasonings. Quality guaranteed with competitive wholesale pricing.",
    location: {
      lat: 26.8167,
      lng: 80.9762,
      address: "1523 Alambagh, Market Place, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "David's Hot Dogs",
        rating: 4,
        comment: "Great for small businesses. Flexible order quantities.",
        date: "Dec 13, 2024",
      },
      {
        id: 2,
        user: "Ahmed's Kebabs",
        rating: 5,
        comment: "Top-notch products and excellent communication.",
        date: "Dec 6, 2024",
      },
    ],
    icon: "🌶️",
  },
  {
    id: 6,
    name: "Street Food Central",
    category: "Packaged Foods",
    rating: 4.4,
    reviewCount: 78,
    description:
      "Premium wholesale supplier specializing in packaged foods for street food vendors and restaurants. We pride ourselves on quality, freshness, and competitive pricing.",
    location: {
      lat: 26.8067,
      lng: 80.9862,
      address: "2156 Indira Nagar, Trade Center, Lucknow, Uttar Pradesh",
    },
    reviews: [
      {
        id: 1,
        user: "Sarah's Sandwiches",
        rating: 4,
        comment: "Reliable partner for my food stall. Quality is always consistent.",
        date: "Dec 5, 2024",
      },
      {
        id: 2,
        user: "Rosa's Empanadas",
        rating: 5,
        comment: "Best wholesale prices in the area. Great for budget-conscious vendors.",
        date: "Dec 4, 2024",
      },
    ],
    icon: "📦",
  },
]

// Default suppliers for fallback (will be replaced with user's actual location)
export const defaultSuppliers: Supplier[] = mockSuppliers
