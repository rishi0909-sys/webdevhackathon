interface Review {
  id: number
  user: string
  rating: number
  comment: string
  date: string
}

interface Supplier {
  id: number
  name: string
  category: string
  rating: number
  reviewCount: number
  description: string
  location: {
    lat: number
    lng: number
    address: string
  }
  reviews: Review[]
  icon: string
}

// Global supplier store
class SupplierStore {
  private suppliers: Supplier[] = []
  private listeners: Array<(suppliers: Supplier[]) => void> = []

  setSuppliers(suppliers: Supplier[]) {
    this.suppliers = suppliers
    this.notifyListeners()
  }

  getSuppliers(): Supplier[] {
    return this.suppliers
  }

  getSupplierById(id: number): Supplier | null {
    return this.suppliers.find((supplier) => supplier.id === id) || null
  }

  // Force initialize with mock suppliers if empty
  initializeWithMockSuppliers() {
    if (this.suppliers.length === 0) {
      // Dynamically import to avoid circular dependencies
      import("./mockSuppliers").then(({ mockSuppliers }) => {
        this.setSuppliers(mockSuppliers)
        console.log("Store initialized with mock suppliers:", mockSuppliers.length)
      })
    }
  }

  subscribe(listener: (suppliers: Supplier[]) => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.suppliers))
  }
}

// Create global instance
export const supplierStore = new SupplierStore()
